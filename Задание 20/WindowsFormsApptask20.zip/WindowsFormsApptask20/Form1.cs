﻿using System;
using System.Windows.Forms;
using System.IO;
using Excel = Microsoft.Office.Interop.Excel;
using System.Reflection;

namespace ExcelAutomationApp
{
    public partial class Form1 : Form
    {
        private string csvFilePath;

        public Form1()
        {
            InitializeComponent();
            csvFilePath = Path.Combine(Application.StartupPath, "data.csv");
        }

        // ================= ПРЕДПРОСМОТР =================
        private void btnPreview_Click(object sender, EventArgs e)
        {
            try
            {
                if (!File.Exists(csvFilePath))
                {
                    MessageBox.Show("CSV файл не найден: " + csvFilePath);
                    return;
                }

                Excel.Application excelApp = new Excel.Application();
                excelApp.Visible = true;

                Excel.Workbook workbook = excelApp.Workbooks.Add(Missing.Value);
                Excel.Worksheet worksheet = (Excel.Worksheet)workbook.Sheets[1];

                string[] csvLines = File.ReadAllLines(csvFilePath);

                for (int i = 0; i < csvLines.Length; i++)
                {
                    string[] cells = csvLines[i].Split(';');
                    for (int j = 0; j < cells.Length; j++)
                    {
                        worksheet.Cells[i + 1, j + 1] = cells[j];
                    }
                }

                worksheet.Columns.AutoFit();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        // ================= ВЫГРУЗКА =================
        private void btnExport_Click(object sender, EventArgs e)
        {
            try
            {
                if (!File.Exists(csvFilePath))
                {
                    MessageBox.Show("CSV файл не найден: " + csvFilePath);
                    return;
                }

                Excel.Application excelApp = new Excel.Application();
                Excel.Workbook workbook = excelApp.Workbooks.Add(Missing.Value);
                Excel.Worksheet worksheet = (Excel.Worksheet)workbook.Sheets[1];

                // ---------- ЗАГОЛОВКИ ----------
                // Строка 3
                Excel.Range header1 = worksheet.get_Range("A3", "A4");
                header1.Merge();
                header1.Value = "№ раздела";
                header1.Orientation = 90;
                header1.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;
                header1.VerticalAlignment = Excel.XlVAlign.xlVAlignCenter;
                header1.Font.Bold = false;

                Excel.Range header2 = worksheet.get_Range("B3", "B4");
                header2.Merge();
                header2.Value = "Наименование раздела дисциплины";
                header2.Orientation = 0;
                header2.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;
                header2.VerticalAlignment = Excel.XlVAlign.xlVAlignCenter;
                header2.Font.Bold = false;

                // Строка с текстом "Виды учебной нагрузки и их трудоемкость, часы"
                Excel.Range workload = worksheet.get_Range("C3", "G3");
                workload.Merge();
                workload.Value = "Виды учебной нагрузки и их трудоемкость, часы";
                workload.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;
                workload.VerticalAlignment = Excel.XlVAlign.xlVAlignCenter;
                workload.Font.Bold = false;

                // Устанавливаем высоту строки 40 пикселей
                Excel.Range row3 = (Excel.Range)worksheet.Rows[3];
                row3.RowHeight = 40;

                // Включаем перенос текста для этой ячейки
                workload.WrapText = true;

                // Строка 4 - подзаголовки
                string[] subHeaders = new string[]
                {
                    "Лекции",
                    "Практические занятия",
                    "Лабораторные работы",
                    "СРС",
                    "Всего часов"
                };

                for (int i = 0; i < subHeaders.Length; i++)
                {
                    Excel.Range cell = (Excel.Range)worksheet.Cells[4, 3 + i];
                    cell.Value = subHeaders[i];
                    cell.Orientation = 90;
                    cell.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;
                    cell.VerticalAlignment = Excel.XlVAlign.xlVAlignCenter;
                    cell.Font.Bold = false;
                }

                // ---------- ДАННЫЕ ----------
                string[] csvLines = File.ReadAllLines(csvFilePath);

                string[] sectionNames = new string[]
                {
                    "Основы демографии как отрасли знаний о населении.",
                    "Воспроизводство и качество населения.",
                    "Режим воспроизводства населения: типы, проблемы роста и демографическая политика.",
                    "Опыт реализации демографической политики в различных стран мира."
                };

                int startRow = 5;
                int dataRows = csvLines.Length - 1;

                for (int i = 0; i < dataRows; i++)
                {
                    string[] cells = csvLines[i].Split(';');

                    // Номер раздела - выравнивание по центру
                    Excel.Range sectionNumCell = (Excel.Range)worksheet.Cells[startRow + i, 1];
                    sectionNumCell.Value = "Раздел " + (i + 1) + ".";
                    sectionNumCell.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;
                    sectionNumCell.VerticalAlignment = Excel.XlVAlign.xlVAlignCenter;

                    // Название раздела - выравнивание по левому краю
                    Excel.Range sectionNameCell = (Excel.Range)worksheet.Cells[startRow + i, 2];
                    sectionNameCell.Value = sectionNames[i];
                    sectionNameCell.HorizontalAlignment = Excel.XlHAlign.xlHAlignLeft;
                    sectionNameCell.VerticalAlignment = Excel.XlVAlign.xlVAlignCenter;
                    sectionNameCell.WrapText = true;

                    // Данные из CSV - все по центру
                    for (int j = 0; j < cells.Length; j++)
                    {
                        Excel.Range dataCell = (Excel.Range)worksheet.Cells[startRow + i, 3 + j];

                        if (int.TryParse(cells[j], out int value))
                            dataCell.Value = value;
                        else
                            dataCell.Value = cells[j] == "-" ? "-" : cells[j];

                        dataCell.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;
                        dataCell.VerticalAlignment = Excel.XlVAlign.xlVAlignCenter;
                    }
                }

                // ---------- ИТОГО ----------
                int totalRow = startRow + dataRows;
                string[] totalCells = csvLines[csvLines.Length - 1].Split(';');

                // Объединение A-B для "ИТОГО:"
                Excel.Range totalTitle = worksheet.get_Range("A" + totalRow, "B" + totalRow);
                totalTitle.Merge();
                totalTitle.Value = "ИТОГО:";
                totalTitle.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;
                totalTitle.VerticalAlignment = Excel.XlVAlign.xlVAlignCenter;

                
                totalTitle.Font.Bold = true; 

                for (int j = 0; j < totalCells.Length; j++)
                {
                    Excel.Range totalDataCell = (Excel.Range)worksheet.Cells[totalRow, 3 + j];

                    if (int.TryParse(totalCells[j], out int value))
                        totalDataCell.Value = value;
                    else
                        totalDataCell.Value = totalCells[j];

                    totalDataCell.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;
                    totalDataCell.VerticalAlignment = Excel.XlVAlign.xlVAlignCenter;

                    
                    totalDataCell.Font.Bold = true;  
                }

                // ---------- ФОРМАТ ----------
                // Весь шрифт Times New Roman 14
                Excel.Range all = worksheet.get_Range("A3", "G" + totalRow);
                all.Font.Name = "Times New Roman";
                all.Font.Size = 14;

                // Границы для всей таблицы
                Excel.Range tableRange = worksheet.get_Range("A3", "G" + totalRow);
                tableRange.Borders.LineStyle = Excel.XlLineStyle.xlContinuous;
                tableRange.Borders.Weight = Excel.XlBorderWeight.xlThin;

                // Толстые внешние границы
                Excel.Range outerRange = worksheet.get_Range("A3", "G" + totalRow);
                outerRange.Borders[Excel.XlBordersIndex.xlEdgeTop].Weight = Excel.XlBorderWeight.xlMedium;
                outerRange.Borders[Excel.XlBordersIndex.xlEdgeBottom].Weight = Excel.XlBorderWeight.xlMedium;
                outerRange.Borders[Excel.XlBordersIndex.xlEdgeLeft].Weight = Excel.XlBorderWeight.xlMedium;
                outerRange.Borders[Excel.XlBordersIndex.xlEdgeRight].Weight = Excel.XlBorderWeight.xlMedium;

                // ========== РУЧНАЯ НАСТРОЙКА ТАБЛИЦЫ ==========
                // 1. ШИРИНА СТОЛБЦОВ
                ((Excel.Range)worksheet.Columns[1]).ColumnWidth = 22;  // № раздела
                ((Excel.Range)worksheet.Columns[2]).ColumnWidth = 45;  // Наименование
                ((Excel.Range)worksheet.Columns[3]).ColumnWidth = 7;   // Лекции
                ((Excel.Range)worksheet.Columns[4]).ColumnWidth = 8;   // Практические
                ((Excel.Range)worksheet.Columns[5]).ColumnWidth = 8;   // Лабораторные
                ((Excel.Range)worksheet.Columns[6]).ColumnWidth = 9;   // СРС
                ((Excel.Range)worksheet.Columns[7]).ColumnWidth = 8;   // Всего часов

                // 2. ВЫСОТА СТРОК
                // Строка 3
                ((Excel.Range)worksheet.Rows[3]).RowHeight = 40;

                // Строка 4
                ((Excel.Range)worksheet.Rows[4]).RowHeight = 100;

                // Строки 5-8 (автоподбор + 10 пикселей)
                for (int i = 5; i <= totalRow; i++)
                {
                    if (i >= 5 && i <= 8) // строки 5-8
                    {
                        Excel.Range currentRow = (Excel.Range)worksheet.Rows[i];
                        currentRow.AutoFit();

                        object heightObj = currentRow.RowHeight;
                        double currentHeight = 25;

                        try
                        {
                            if (heightObj != null)
                            {
                                if (heightObj is double)
                                    currentHeight = (double)heightObj;
                                else if (heightObj is float)
                                    currentHeight = (double)(float)heightObj;
                                else if (heightObj is int)
                                    currentHeight = (double)(int)heightObj;
                                else if (heightObj is decimal)
                                    currentHeight = (double)(decimal)heightObj;
                                else
                                    currentHeight = Convert.ToDouble(heightObj);
                            }
                        }
                        catch
                        {
                            currentHeight = 25;
                        }

                        currentRow.RowHeight = currentHeight + 10;
                    }
                    else if (i == totalRow) // Строка "ИТОГО"
                    {
                        ((Excel.Range)worksheet.Rows[i]).RowHeight = 25;
                    }
                    else
                    {
                        ((Excel.Range)worksheet.Rows[i]).RowHeight = 25;
                    }
                }

                // =================================================

                // Выравнивание по центру для всех ячеек с повернутым текстом
                Excel.Range rotatedCells = worksheet.get_Range("A3:B4");
                rotatedCells.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;
                rotatedCells.VerticalAlignment = Excel.XlVAlign.xlVAlignCenter;

                // Выравнивание по центру для всех числовых данных
                Excel.Range dataCells = worksheet.get_Range("C3", "G" + totalRow);
                dataCells.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;
                dataCells.VerticalAlignment = Excel.XlVAlign.xlVAlignCenter;

                // Перенос текста для столбца B
                ((Excel.Range)worksheet.Columns[2]).WrapText = true;

                // Перенос текста для числовых столбцов
                for (int col = 3; col <= 7; col++)
                {
                    ((Excel.Range)worksheet.Columns[col]).WrapText = true;
                }

                // Перенос текста для объединенной ячейки C3:G3
                Excel.Range mergedWorkload = worksheet.get_Range("C3", "G3");
                mergedWorkload.WrapText = true;

                // Строки 3-4 (заголовки) - НЕжирные
                Excel.Range headersRange = worksheet.get_Range("A3", "G4");
                headersRange.Font.Bold = false;

                // Строки 5-8 (данные разделов) - НЕжирные
                Excel.Range dataRange = worksheet.get_Range("A5", "G8");
                dataRange.Font.Bold = false;

                // Показываем Excel
                excelApp.Visible = true;

                // Сохраняем файл
                string savePath = Path.Combine(Application.StartupPath, "Учебный_план.xlsx");
                workbook.SaveAs(savePath);

                MessageBox.Show("Файл успешно создан: " + savePath);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message);
            }
        }
    }
}