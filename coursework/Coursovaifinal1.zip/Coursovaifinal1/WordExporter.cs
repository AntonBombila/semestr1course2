﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using Word = Microsoft.Office.Interop.Word;

namespace CourseWorkApp
{
    public static class WordExporter
    {
        public static void ExportToWord(List<WorkloadItem> items, string filePath)
        {
            Word.Application wordApp = null;
            Word.Document doc = null;

            try
            {
                wordApp = new Word.Application();
                wordApp.Visible = false;
                doc = wordApp.Documents.Add();

                Word.Paragraph title = doc.Content.Paragraphs.Add();
                title.Range.Text = "УЧЕТ УЧЕБНОЙ НАГРУЗКИ ПРЕПОДАВАТЕЛЕЙ";
                title.Range.Font.Bold = 1;
                title.Range.Font.Size = 16;
                title.Range.ParagraphFormat.Alignment = Word.WdParagraphAlignment.wdAlignParagraphCenter;
                title.Format.SpaceAfter = 24;
                title.Range.InsertParagraphAfter();

                Word.Paragraph dateParagraph = doc.Content.Paragraphs.Add();
                dateParagraph.Range.Text = $"Дата экспорта: {DateTime.Now:dd.MM.yyyy HH:mm}";
                dateParagraph.Range.Font.Size = 10;
                dateParagraph.Range.Font.Italic = 1;
                dateParagraph.Format.SpaceAfter = 12;
                dateParagraph.Range.InsertParagraphAfter();

                int totalPlanned = items.Sum(i => i.PlannedHours);
                int totalActual = items.Sum(i => i.ActualHours);

                Word.Paragraph statsParagraph = doc.Content.Paragraphs.Add();
                statsParagraph.Range.Text = $"Всего записей: {items.Count} | " +
                                          $"Преподавателей: {items.Select(i => i.TeacherName).Distinct().Count()} | " +
                                          $"Плановых часов: {totalPlanned} | " +
                                          $"Фактических часов: {totalActual}";
                statsParagraph.Range.Font.Size = 10;
                statsParagraph.Range.Font.Bold = 1;
                statsParagraph.Format.SpaceAfter = 18;
                statsParagraph.Range.InsertParagraphAfter();

                if (items.Count == 0)
                {
                    Word.Paragraph noDataParagraph = doc.Content.Paragraphs.Add();
                    noDataParagraph.Range.Text = "Нет данных для отображения";
                    noDataParagraph.Range.Font.Size = 12;
                    noDataParagraph.Range.Font.Italic = 1;
                    noDataParagraph.Range.Font.Color = Word.WdColor.wdColorRed;
                    noDataParagraph.Format.SpaceAfter = 12;
                    noDataParagraph.Range.InsertParagraphAfter();
                }
                else
                {
                    // Создаем таблицу с 13 колонками (без разницы и статуса)
                    int rows = items.Count + 1;
                    int columns = 13;

                    Word.Table table = doc.Tables.Add(doc.Content, rows, columns);
                    table.Borders.Enable = 1;

                    // Заголовки таблицы - 13 столбцов
                    string[] headers = new string[]
                    {
                        "ФИО преподавателя", "Должность", "Степень", "Звание",
                        "Ставка", "Тип занятости", "Учебный год", "Семестр",
                        "Дисциплина", "Группа", "Вид занятия", "План (ч)", "Факт (ч)"
                    };

                    for (int i = 0; i < headers.Length; i++)
                    {
                        table.Cell(1, i + 1).Range.Text = headers[i];
                        table.Cell(1, i + 1).Range.Font.Bold = 1;
                        table.Cell(1, i + 1).Range.ParagraphFormat.Alignment = Word.WdParagraphAlignment.wdAlignParagraphCenter;
                        table.Cell(1, i + 1).Range.Shading.BackgroundPatternColor = Word.WdColor.wdColorGray15;
                    }

                    // Заполняем таблицу данными
                    for (int i = 0; i < items.Count; i++)
                    {
                        var item = items[i];

                        table.Cell(i + 2, 1).Range.Text = item.TeacherName ?? "";
                        table.Cell(i + 2, 2).Range.Text = item.Position ?? "";
                        table.Cell(i + 2, 3).Range.Text = item.AcademicDegree ?? "";
                        table.Cell(i + 2, 4).Range.Text = item.AcademicTitle ?? "";
                        table.Cell(i + 2, 5).Range.Text = item.StaffRate.ToString("0.0");
                        table.Cell(i + 2, 6).Range.Text = item.EmploymentType ?? "";
                        table.Cell(i + 2, 7).Range.Text = item.AcademicYear.ToString();
                        table.Cell(i + 2, 8).Range.Text = item.Semester.ToString();
                        table.Cell(i + 2, 9).Range.Text = item.Discipline ?? "";
                        table.Cell(i + 2, 10).Range.Text = item.Group ?? "";
                        table.Cell(i + 2, 11).Range.Text = item.ActivityType ?? "";
                        table.Cell(i + 2, 12).Range.Text = item.PlannedHours.ToString();
                        table.Cell(i + 2, 13).Range.Text = item.ActualHours.ToString();
                    }

                    table.AutoFitBehavior(Word.WdAutoFitBehavior.wdAutoFitContent);

                    Word.Range range = doc.Content;
                    range.Collapse(Word.WdCollapseDirection.wdCollapseEnd);
                    range.InsertParagraphAfter();

                    Word.Paragraph totalParagraph = doc.Content.Paragraphs.Add();
                    totalParagraph.Range.Text = $"ИТОГО: Плановых часов: {totalPlanned} | " +
                                               $"Фактических часов: {totalActual}";
                    totalParagraph.Range.Font.Bold = 1;
                    totalParagraph.Range.Font.Size = 11;
                }

                try
                {
                    object fileName = filePath;
                    object fileFormat = Word.WdSaveFormat.wdFormatDocumentDefault;
                    object missing = Type.Missing;

                    doc.SaveAs2(ref fileName, ref fileFormat, ref missing, ref missing, ref missing,
                        ref missing, ref missing, ref missing, ref missing, ref missing, ref missing,
                        ref missing, ref missing, ref missing, ref missing, ref missing);
                }
                catch (Exception ex)
                {
                    throw new Exception("Ошибка сохранения файла: " + ex.Message);
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Ошибка при экспорте в Word: " + ex.Message);
            }
            finally
            {
                if (doc != null)
                {
                    doc.Close(false);
                    Marshal.ReleaseComObject(doc);
                }
                if (wordApp != null)
                {
                    wordApp.Quit(false);
                    Marshal.ReleaseComObject(wordApp);
                }
            }
        }
    }
}