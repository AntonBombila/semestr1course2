﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using System.Text;
using System.Runtime.InteropServices;
using Excel = Microsoft.Office.Interop.Excel;

namespace CourseWorkApp
{
    public partial class MainForm : Form
    {
        private Chart _chartControl;
        private BindingList<WorkloadItem> _items = new BindingList<WorkloadItem>();
        private List<WorkloadItem> _allItems = new List<WorkloadItem>();
        private Panel _tableContainerPanel;
        private ContextMenuStrip _contextMenuHours;

        public MainForm()
        {
            this.WindowState = FormWindowState.Maximized;
            InitializeComponent();
            CreateAndReplaceChart();
            SetupForm();
            SetupContextMenu();
        }

        private void CreateAndReplaceChart()
        {
            // Создаем настоящий Chart
            _chartControl = new Chart();
            _chartControl.Dock = chartWorkload.Dock;
            _chartControl.Location = chartWorkload.Location;
            _chartControl.Size = new Size(chartWorkload.Width, 250);
            _chartControl.Name = "chartWorkload";
            _chartControl.BackColor = Color.White;

            // Настраиваем Chart
            ChartArea chartArea = new ChartArea("MainArea");
            chartArea.AxisX.LabelStyle.Angle = -45;
            chartArea.AxisX.LabelStyle.Font = new Font("Arial", 8);
            chartArea.AxisY.LabelStyle.Format = "#,##0";
            _chartControl.ChartAreas.Add(chartArea);

            Legend legend = new Legend("MainLegend");
            legend.Docking = Docking.Bottom;
            legend.Alignment = StringAlignment.Center;
            _chartControl.Legends.Add(legend);

            // Создаем Panel для таблицы с прокруткой
            _tableContainerPanel = new Panel();
            _tableContainerPanel.Dock = DockStyle.Fill;
            _tableContainerPanel.AutoScroll = true;
            _tableContainerPanel.Controls.Add(dataGridView);

            // Создаем SplitContainer
            SplitContainer splitContainer = new SplitContainer();
            splitContainer.Dock = DockStyle.Fill;
            splitContainer.Orientation = Orientation.Vertical;
            splitContainer.SplitterDistance = 700;
            splitContainer.FixedPanel = FixedPanel.Panel1;

            // Добавляем элементы
            splitContainer.Panel1.Controls.Add(_tableContainerPanel);
            splitContainer.Panel2.Controls.Add(_chartControl);

            // Заменяем элементы
            var parent = chartWorkload.Parent;
            int chartIndex = parent.Controls.IndexOf(chartWorkload);
            parent.Controls.Remove(chartWorkload);
            parent.Controls.Add(splitContainer);
            parent.Controls.SetChildIndex(splitContainer, chartIndex);
        }

        private void SetupForm()
        {
            // Настройка DataGridView
            dataGridView.DataSource = _items;
            dataGridView.ReadOnly = false;
            dataGridView.AllowUserToAddRows = false;
            dataGridView.AllowUserToDeleteRows = false;
            dataGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            dataGridView.ColumnHeadersDefaultCellStyle.Font = new Font("Arial", 9, FontStyle.Bold);

            dataGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None;
            dataGridView.Columns.Clear();
            AddDataGridViewColumns();

            // Заполнение комбобоксов
            FillComboBoxes();

            // Установка дат по умолчанию
            dtpStart.Value = new DateTime(DateTime.Now.Year, 1, 1);
            dtpEnd.Value = DateTime.Now;

            // Подключение событий
            btnLoadCsv.Click += new EventHandler(btnLoadCsv_Click);
            btnLoadFolder.Click += new EventHandler(btnLoadFolder_Click);
            btnLoadWord.Click += new EventHandler(btnLoadWord_Click);
            btnExportCsv.Click += new EventHandler(btnExportCsv_Click);
            btnClear.Click += new EventHandler(btnClear_Click);
            btnGenerateChart.Click += new EventHandler(btnGenerateChart_Click);
            btnExportExcel.Click += new EventHandler(BtnExportExcel_Click);
            btnExportWord.Click += new EventHandler(btnExportWord_Click);
            btnUpdateStats.Click += new EventHandler(BtnUpdateStats_Click);

            // События DataGridView
            dataGridView.CellEndEdit += new DataGridViewCellEventHandler(dataGridView_CellEndEdit);
            dataGridView.CellFormatting += new DataGridViewCellFormattingEventHandler(dataGridView_CellFormatting);

            this.Load += new EventHandler(MainForm_Load);
        }

        private void SetupContextMenu()
        {
            _contextMenuHours = new ContextMenuStrip();

            ToolStripMenuItem setActualEqualPlan = new ToolStripMenuItem("Установить факт = плану");
            setActualEqualPlan.Click += (s, e) => SetActualEqualToPlan();

            ToolStripMenuItem clearActual = new ToolStripMenuItem("Очистить фактические часы");
            clearActual.Click += (s, e) => ClearActualHours();

            ToolStripMenuItem calculateAuto = new ToolStripMenuItem("Авторасчет (80% от плана)");
            calculateAuto.Click += (s, e) => CalculateAutoHours();

            _contextMenuHours.Items.Add(setActualEqualPlan);
            _contextMenuHours.Items.Add(clearActual);
            _contextMenuHours.Items.Add(calculateAuto);

            dataGridView.ContextMenuStrip = _contextMenuHours;
        }

        private void SetActualEqualToPlan()
        {
            if (dataGridView.SelectedRows.Count > 0)
            {
                foreach (DataGridViewRow row in dataGridView.SelectedRows)
                {
                    var item = _items[row.Index];
                    item.ActualHours = item.PlannedHours;

                    var originalItem = _allItems.FirstOrDefault(i =>
                        i.TeacherName == item.TeacherName &&
                        i.Discipline == item.Discipline &&
                        i.AcademicYear == item.AcademicYear &&
                        i.Semester == item.Semester);

                    if (originalItem != null)
                    {
                        originalItem.ActualHours = item.PlannedHours;
                    }
                }

                UpdateStatistics();
                dataGridView.Refresh();
            }
        }

        private void ClearActualHours()
        {
            if (dataGridView.SelectedRows.Count > 0)
            {
                foreach (DataGridViewRow row in dataGridView.SelectedRows)
                {
                    var item = _items[row.Index];
                    item.ActualHours = 0;

                    var originalItem = _allItems.FirstOrDefault(i =>
                        i.TeacherName == item.TeacherName &&
                        i.Discipline == item.Discipline &&
                        i.AcademicYear == item.AcademicYear &&
                        i.Semester == item.Semester);

                    if (originalItem != null)
                    {
                        originalItem.ActualHours = 0;
                    }
                }

                UpdateStatistics();
                dataGridView.Refresh();
            }
        }

        private void CalculateAutoHours()
        {
            if (dataGridView.SelectedRows.Count > 0)
            {
                foreach (DataGridViewRow row in dataGridView.SelectedRows)
                {
                    var item = _items[row.Index];
                    item.ActualHours = (int)(item.PlannedHours * 0.8m);

                    var originalItem = _allItems.FirstOrDefault(i =>
                        i.TeacherName == item.TeacherName &&
                        i.Discipline == item.Discipline &&
                        i.AcademicYear == item.AcademicYear &&
                        i.Semester == item.Semester);

                    if (originalItem != null)
                    {
                        originalItem.ActualHours = (int)(item.PlannedHours * 0.8m);
                    }
                }

                UpdateStatistics();
                dataGridView.Refresh();
            }
        }

        private void AddDataGridViewColumns()
        {
            // Столбец ФИО
            DataGridViewTextBoxColumn teacherColumn = new DataGridViewTextBoxColumn();
            teacherColumn.DataPropertyName = "TeacherName";
            teacherColumn.HeaderText = "ФИО";
            teacherColumn.Width = 150;
            teacherColumn.MinimumWidth = 100;
            teacherColumn.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            teacherColumn.ReadOnly = true;
            dataGridView.Columns.Add(teacherColumn);

            // Остальные столбцы
            string[] columns = new string[]
            {
                "Position", "AcademicDegree", "AcademicTitle", "StaffRate",
                "EmploymentType", "AcademicYear", "Semester", "Discipline",
                "Group", "ActivityType"
            };

            string[] headers = new string[]
            {
                "Должность", "Степень", "Звание", "Ставка", "Тип",
                "Год", "Сем.", "Дисциплина", "Группа", "Вид занятия"
            };

            int[] widths = new int[]
            {
                120, 100, 100, 70, 80, 60, 50, 200, 80, 100
            };

            for (int i = 0; i < columns.Length; i++)
            {
                DataGridViewTextBoxColumn column = new DataGridViewTextBoxColumn();
                column.DataPropertyName = columns[i];
                column.HeaderText = headers[i];
                column.Width = widths[i];
                column.MinimumWidth = 50;
                column.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                column.ReadOnly = true;

                if (columns[i] == "StaffRate")
                {
                    column.DefaultCellStyle.Format = "0.0";
                }

                dataGridView.Columns.Add(column);
            }

            // Плановые часы
            DataGridViewTextBoxColumn plannedColumn = new DataGridViewTextBoxColumn();
            plannedColumn.DataPropertyName = "PlannedHours";
            plannedColumn.HeaderText = "План (ч)";
            plannedColumn.Width = 70;
            plannedColumn.MinimumWidth = 60;
            plannedColumn.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            plannedColumn.ReadOnly = true;
            dataGridView.Columns.Add(plannedColumn);

            // Фактические часы
            DataGridViewTextBoxColumn actualColumn = new DataGridViewTextBoxColumn();
            actualColumn.DataPropertyName = "ActualHours";
            actualColumn.HeaderText = "Факт (ч)";
            actualColumn.Width = 70;
            actualColumn.MinimumWidth = 60;
            actualColumn.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            actualColumn.ReadOnly = false;
            dataGridView.Columns.Add(actualColumn);

            // Совместитель (скрытый столбец)
            DataGridViewCheckBoxColumn externalColumn = new DataGridViewCheckBoxColumn();
            externalColumn.DataPropertyName = "IsExternal";
            externalColumn.HeaderText = "Совместитель";
            externalColumn.Width = 80;
            externalColumn.Visible = false;
            dataGridView.Columns.Add(externalColumn);
        }

        private void FillComboBoxes()
        {
            comboYear.Items.Clear();
            comboAcademicYear.Items.Clear();

            int currentYear = DateTime.Now.Year;
            for (int year = 2015; year <= currentYear; year++)
            {
                comboYear.Items.Add(year);
                comboAcademicYear.Items.Add(string.Format("{0}/{1}", year, year + 1));
            }

            // Проверяем, есть ли элементы в комбобоксах
            if (comboYear.Items.Count > 0)
            {
                comboYear.SelectedIndex = comboYear.Items.Count - 1;
            }

            if (comboAcademicYear.Items.Count > 0)
            {
                comboAcademicYear.SelectedIndex = comboAcademicYear.Items.Count - 1;
            }

            comboSemester.Items.Clear();
            comboSemester.Items.Add("1 семестр");
            comboSemester.Items.Add("2 семестр");
            comboSemester.SelectedIndex = 0;

            comboChartType.Items.Clear();
            comboChartType.Items.Add("1. Нагрузка по видам занятий (календарный год)");
            comboChartType.Items.Add("2. Нагрузка по видам занятий (учебный год)");
            comboChartType.Items.Add("3. Нагрузка по видам занятий (семестр)");
            comboChartType.Items.Add("4. Нагрузка преподавателей за период");
            comboChartType.Items.Add("5. Распределение ставок преподавателей");
            comboChartType.Items.Add("6. Основные сотрудники и совместители");
            comboChartType.SelectedIndex = 0;
        }

        private void ConfigureDataGridView()
        {
            if (dataGridView.Columns.Count > 0)
            {
                foreach (DataGridViewColumn column in dataGridView.Columns)
                {
                    if (column.DataPropertyName == "StaffRate")
                    {
                        column.DefaultCellStyle.Format = "0.0";
                    }

                    // Обновляем названия столбцов
                    switch (column.DataPropertyName)
                    {
                        case "TeacherName": column.HeaderText = "ФИО"; break;
                        case "Position": column.HeaderText = "Должность"; break;
                        case "AcademicDegree": column.HeaderText = "Степень"; break;
                        case "AcademicTitle": column.HeaderText = "Звание"; break;
                        case "StaffRate": column.HeaderText = "Ставка"; break;
                        case "EmploymentType": column.HeaderText = "Тип"; break;
                        case "AcademicYear": column.HeaderText = "Год"; break;
                        case "Semester": column.HeaderText = "Сем."; break;
                        case "Discipline": column.HeaderText = "Дисциплина"; break;
                        case "Group": column.HeaderText = "Группа"; break;
                        case "ActivityType": column.HeaderText = "Вид занятия"; break;
                        case "PlannedHours": column.HeaderText = "План (ч)"; break;
                        case "ActualHours": column.HeaderText = "Факт (ч)"; break;
                        case "IsExternal": column.HeaderText = "Совместитель"; column.Visible = false; break;
                    }
                }
                dataGridView.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);
            }
        }

        private void UpdateDataGridView()
        {
            _items.Clear();
            foreach (var item in _allItems)
                _items.Add(item);

            ConfigureDataGridView();
            UpdateStatistics();
            UpdateTeachersComboBox(); // Обновляем список преподавателей
        }

        private void UpdateTeachersComboBox()
        {
            comboTeachers.Items.Clear();

            if (_allItems.Count == 0)
            {
                return;
            }

            // Получаем уникальных преподавателей
            var teachers = _allItems
                .Select(item => item.TeacherName)
                .Where(name => !string.IsNullOrEmpty(name))
                .Distinct()
                .OrderBy(name => name)
                .ToList();

            foreach (var teacher in teachers)
            {
                comboTeachers.Items.Add(teacher);
            }

            if (comboTeachers.Items.Count > 0)
            {
                comboTeachers.SelectedIndex = 0;
            }
            else
            {
                txtHoursSemester.Text = "0";
                txtHoursAcademicYear.Text = "0";
            }
        }

        private void UpdateStatistics()
        {
            lblTotalRecords.Text = string.Format("Всего записей: {0}", _allItems.Count);

            Dictionary<string, bool> teachers = new Dictionary<string, bool>();
            foreach (var item in _allItems)
            {
                if (!string.IsNullOrEmpty(item.TeacherName) && !teachers.ContainsKey(item.TeacherName))
                {
                    teachers.Add(item.TeacherName, true);
                }
            }
            lblTotalTeachers.Text = string.Format("Преподавателей: {0}", teachers.Count);

            if (dataGridView.Columns.Count > 0)
            {
                dataGridView.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);
            }
        }

        private void UpdateTeacherHoursStatistics()
        {
            if (comboTeachers.SelectedItem == null)
            {
                txtHoursSemester.Text = "0";
                txtHoursAcademicYear.Text = "0";
                return;
            }

            string selectedTeacher = comboTeachers.SelectedItem.ToString();

            // Получаем выбранный учебный год и семестр
            string academicYear = comboAcademicYear.Text;
            int semester = comboSemester.SelectedIndex + 1;

            if (string.IsNullOrEmpty(academicYear))
            {
                txtHoursSemester.Text = "Выберите учебный год";
                txtHoursAcademicYear.Text = "Выберите учебный год";
                return;
            }

            // Парсим учебный год
            string[] yearParts = academicYear.Split('/');
            if (yearParts.Length < 2 || !int.TryParse(yearParts[0], out int startYear))
            {
                txtHoursSemester.Text = "Ошибка формата года";
                txtHoursAcademicYear.Text = "Ошибка формата года";
                return;
            }

            // Рассчитываем часы за семестр
            int semesterHours = CalculateHoursForSemester(selectedTeacher, startYear, semester);
            txtHoursSemester.Text = semesterHours.ToString();

            // Рассчитываем часы за учебный год
            int academicYearHours = CalculateHoursForAcademicYear(selectedTeacher, startYear);
            txtHoursAcademicYear.Text = academicYearHours.ToString();
        }

        private int CalculateHoursForSemester(string teacherName, int academicYearStart, int semester)
        {
            int semesterYear = academicYearStart;
            if (semester == 2)
            {
                semesterYear = academicYearStart + 1;
            }

            return _allItems
                .Where(item => item.TeacherName == teacherName &&
                              item.AcademicYear == semesterYear &&
                              item.Semester == semester)
                .Sum(item => item.PlannedHours);
        }

        private int CalculateHoursForAcademicYear(string teacherName, int academicYearStart)
        {
            return _allItems
                .Where(item => item.TeacherName == teacherName &&
                              (item.AcademicYear == academicYearStart ||
                               item.AcademicYear == academicYearStart + 1))
                .Sum(item => item.PlannedHours);
        }

        private int GetSemesterYear(int academicYearStart, int semester)
        {
            if (semester == 1)
                return academicYearStart;
            else if (semester == 2)
                return academicYearStart + 1;
            else
                return academicYearStart;
        }

        private void DrawColumnChart(List<string> labels, List<int> values,
            string title, string xTitle, string yTitle)
        {
            if (_chartControl == null) return;

            _chartControl.Series.Clear();
            _chartControl.Titles.Clear();
            _chartControl.ChartAreas.Clear();

            ChartArea chartArea = new ChartArea("MainArea");

            if (values.Count > 0)
            {
                int maxValue = values.Max();
                chartArea.AxisY.Maximum = maxValue * 1.1;
                chartArea.AxisY.Minimum = 0;
                chartArea.AxisY.Interval = CalculateOptimalInterval(maxValue);
            }

            chartArea.AxisX.LabelStyle.Angle = -45;
            chartArea.AxisX.LabelStyle.Font = new Font("Arial", 8);
            chartArea.AxisY.LabelStyle.Format = "#,##0";
            _chartControl.ChartAreas.Add(chartArea);

            int maxItems = 15;
            if (labels.Count > maxItems)
            {
                labels = labels.Take(maxItems).ToList();
                values = values.Take(maxItems).ToList();
            }

            Series series = new Series("Нагрузка");
            series.ChartType = SeriesChartType.Column;
            series.IsValueShownAsLabel = true;
            series.LabelFormat = "#,##0";
            series.Color = Color.SteelBlue;
            series.Font = new Font("Arial", 8);
            series["PointWidth"] = "0.6";

            for (int i = 0; i < labels.Count; i++)
            {
                DataPoint point = series.Points.Add(values[i]);
                string shortLabel = labels[i];
                if (shortLabel.Length > 25)
                    shortLabel = shortLabel.Substring(0, 25) + "...";
                point.AxisLabel = shortLabel;
                point.Label = values[i].ToString("#,##0");
                point.Font = new Font("Arial", 8);
                point.Color = GetColorForIndex(i);
            }

            _chartControl.Series.Add(series);

            Title chartTitle = new Title(title, Docking.Top,
                new Font("Arial", 12, FontStyle.Bold), Color.Black);
            _chartControl.Titles.Add(chartTitle);

            _chartControl.ChartAreas[0].AxisX.Title = xTitle;
            _chartControl.ChartAreas[0].AxisY.Title = yTitle;
            _chartControl.ChartAreas[0].AxisX.Interval = 1;
            _chartControl.ChartAreas[0].AxisX.LabelStyle.Angle = -45;
            _chartControl.ChartAreas[0].AxisX.LabelStyle.Font = new Font("Arial", 8);
            _chartControl.ChartAreas[0].AxisY.LabelStyle.Format = "#,##0";
            _chartControl.ChartAreas[0].AxisY.TitleFont = new Font("Arial", 9);
            _chartControl.ChartAreas[0].AxisX.TitleFont = new Font("Arial", 9);

            _chartControl.Legends[0].Enabled = false;

            if (labels.Count > 8)
            {
                _chartControl.ChartAreas[0].AxisX.LabelStyle.Font = new Font("Arial", 7);
            }
        }

        private double CalculateOptimalInterval(int maxValue)
        {
            if (maxValue <= 100) return 10;
            if (maxValue <= 500) return 50;
            if (maxValue <= 1000) return 100;
            if (maxValue <= 5000) return 500;
            if (maxValue <= 10000) return 1000;
            return 2000;
        }

        private Color GetColorForIndex(int index)
        {
            Color[] colors = new Color[]
            {
                Color.SteelBlue,
                Color.IndianRed,
                Color.MediumSeaGreen,
                Color.Goldenrod,
                Color.MediumPurple,
                Color.Teal,
                Color.Coral,
                Color.CornflowerBlue,
                Color.DarkOliveGreen,
                Color.DarkOrchid,
                Color.DarkSalmon,
                Color.DarkSlateGray,
                Color.DeepPink,
                Color.DodgerBlue,
                Color.ForestGreen
            };
            return colors[index % colors.Length];
        }

        // Методы для экспорта статистики преподавателя
        private void ExportTeacherStatsToTxt(string teacherName, List<WorkloadItem> teacherItems, string academicYear, string filePath)
        {
            try
            {
                using (StreamWriter writer = new StreamWriter(filePath, false, Encoding.UTF8))
                {
                    writer.WriteLine("СТАТИСТИКА ПРЕПОДАВАТЕЛЯ");
                    writer.WriteLine(new string('=', 50));
                    writer.WriteLine("Преподаватель: " + teacherName);
                    writer.WriteLine("Учебный год: " + academicYear);
                    writer.WriteLine("Дата формирования: " + DateTime.Now.ToString("dd.MM.yyyy HH:mm"));
                    writer.WriteLine(new string('-', 50));

                    // Общая статистика
                    int totalPlannedHours = teacherItems.Sum(i => i.PlannedHours);
                    int totalActualHours = teacherItems.Sum(i => i.ActualHours);
                    int semesterHours = CalculateHoursForSemester(teacherName,
                        int.Parse(academicYear.Split('/')[0]), comboSemester.SelectedIndex + 1);
                    int academicYearHours = CalculateHoursForAcademicYear(teacherName,
                        int.Parse(academicYear.Split('/')[0]));

                    writer.WriteLine("ОБЩАЯ СТАТИСТИКА:");
                    writer.WriteLine("  Всего записей: " + teacherItems.Count);
                    writer.WriteLine("  Плановых часов всего: " + totalPlannedHours);
                    writer.WriteLine("  Фактических часов всего: " + totalActualHours);
                    writer.WriteLine("  Часов за текущий семестр: " + semesterHours);
                    writer.WriteLine("  Часов за учебный год: " + academicYearHours);
                    writer.WriteLine(new string('-', 50));

                    // Статистика по семестрам
                    writer.WriteLine("СТАТИСТИКА ПО СЕМЕСТРАМ:");
                    var semesterStats = teacherItems
                        .GroupBy(i => i.Semester)
                        .Select(g => new
                        {
                            Semester = g.Key,
                            Count = g.Count(),
                            PlannedHours = g.Sum(i => i.PlannedHours),
                            ActualHours = g.Sum(i => i.ActualHours)
                        })
                        .OrderBy(s => s.Semester);

                    foreach (var stat in semesterStats)
                    {
                        writer.WriteLine("  Семестр " + stat.Semester + ":");
                        writer.WriteLine("    Записей: " + stat.Count);
                        writer.WriteLine("    Плановых часов: " + stat.PlannedHours);
                        writer.WriteLine("    Фактических часов: " + stat.ActualHours);
                    }
                    writer.WriteLine(new string('-', 50));

                    // Статистика по видам занятий
                    writer.WriteLine("СТАТИСТИКА ПО ВИДАМ ЗАНЯТИЙ:");
                    var activityStats = teacherItems
                        .GroupBy(i => i.ActivityType)
                        .Select(g => new
                        {
                            ActivityType = g.Key,
                            Count = g.Count(),
                            PlannedHours = g.Sum(i => i.PlannedHours),
                            ActualHours = g.Sum(i => i.ActualHours)
                        })
                        .OrderByDescending(a => a.PlannedHours);

                    foreach (var stat in activityStats)
                    {
                        writer.WriteLine("  " + stat.ActivityType + ":");
                        writer.WriteLine("    Записей: " + stat.Count);
                        writer.WriteLine("    Плановых часов: " + stat.PlannedHours);
                        writer.WriteLine("    Фактических часов: " + stat.ActualHours);
                    }
                    writer.WriteLine(new string('-', 50));

                    // Детализация по дисциплинам
                    writer.WriteLine("ДЕТАЛИЗАЦИЯ ПО ДИСЦИПЛИНАМ:");
                    var disciplineStats = teacherItems
                        .GroupBy(i => i.Discipline)
                        .Select(g => new
                        {
                            Discipline = g.Key,
                            Count = g.Count(),
                            PlannedHours = g.Sum(i => i.PlannedHours),
                            ActualHours = g.Sum(i => i.ActualHours),
                            Groups = string.Join(", ", g.Select(x => x.Group).Distinct().ToArray())
                        })
                        .OrderByDescending(d => d.PlannedHours);

                    foreach (var stat in disciplineStats)
                    {
                        writer.WriteLine("  " + stat.Discipline + ":");
                        writer.WriteLine("    Группы: " + stat.Groups);
                        writer.WriteLine("    Записей: " + stat.Count);
                        writer.WriteLine("    Плановых часов: " + stat.PlannedHours);
                        writer.WriteLine("    Фактических часов: " + stat.ActualHours);
                        writer.WriteLine();
                    }

                    writer.WriteLine(new string('=', 50));
                    writer.WriteLine("КОНЕЦ ОТЧЕТА");
                }

                MessageBox.Show("Статистика преподавателя экспортирована в файл:\n" + filePath,
                    "Экспорт завершен", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при экспорте статистики: " + ex.Message,
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ExportTeacherStatsToCsv(string teacherName, List<WorkloadItem> teacherItems, string academicYear, string filePath)
        {
            try
            {
                using (StreamWriter writer = new StreamWriter(filePath, false, Encoding.GetEncoding(1251)))
                {
                    // Заголовок
                    writer.WriteLine("Статистика преподавателя: " + teacherName);
                    writer.WriteLine("Учебный год: " + academicYear);
                    writer.WriteLine("Дата формирования: " + DateTime.Now.ToString("dd.MM.yyyy HH:mm"));
                    writer.WriteLine();

                    // Общая статистика
                    writer.WriteLine("ОБЩАЯ СТАТИСТИКА");
                    writer.WriteLine("Параметр;Значение");
                    writer.WriteLine("Всего записей;" + teacherItems.Count);
                    writer.WriteLine("Плановых часов всего;" + teacherItems.Sum(i => i.PlannedHours));
                    writer.WriteLine("Фактических часов всего;" + teacherItems.Sum(i => i.ActualHours));
                    writer.WriteLine("Часов за текущий семестр;" + txtHoursSemester.Text);
                    writer.WriteLine("Часов за учебный год;" + txtHoursAcademicYear.Text);
                    writer.WriteLine();

                    // Статистика по семестрам
                    writer.WriteLine("СТАТИСТИКА ПО СЕМЕСТРАМ");
                    writer.WriteLine("Семестр;Количество записей;Плановых часов;Фактических часов");

                    var semesterStats = teacherItems
                        .GroupBy(i => i.Semester)
                        .Select(g => new
                        {
                            Semester = g.Key,
                            Count = g.Count(),
                            PlannedHours = g.Sum(i => i.PlannedHours),
                            ActualHours = g.Sum(i => i.ActualHours)
                        })
                        .OrderBy(s => s.Semester);

                    foreach (var stat in semesterStats)
                    {
                        writer.WriteLine(stat.Semester + ";" + stat.Count + ";" + stat.PlannedHours + ";" + stat.ActualHours);
                    }
                    writer.WriteLine();

                    // Статистика по видам занятий
                    writer.WriteLine("СТАТИСТИКА ПО ВИДАМ ЗАНЯТИЙ");
                    writer.WriteLine("Вид занятия;Количество записей;Плановых часов;Фактических часов");

                    var activityStats = teacherItems
                        .GroupBy(i => i.ActivityType)
                        .Select(g => new
                        {
                            ActivityType = g.Key,
                            Count = g.Count(),
                            PlannedHours = g.Sum(i => i.PlannedHours),
                            ActualHours = g.Sum(i => i.ActualHours)
                        })
                        .OrderByDescending(a => a.PlannedHours);

                    foreach (var stat in activityStats)
                    {
                        writer.WriteLine(stat.ActivityType + ";" + stat.Count + ";" + stat.PlannedHours + ";" + stat.ActualHours);
                    }
                    writer.WriteLine();

                    // Детализация по дисциплинам
                    writer.WriteLine("ДЕТАЛИЗАЦИЯ ПО ДИСЦИПЛИНАМ");
                    writer.WriteLine("Дисциплина;Группа;Семестр;Вид занятия;Плановых часов;Фактических часов;Ставка");

                    var detailedStats = teacherItems
                        .OrderBy(i => i.Discipline)
                        .ThenBy(i => i.Group)
                        .ThenBy(i => i.Semester);

                    foreach (var item in detailedStats)
                    {
                        writer.WriteLine(item.Discipline + ";" + item.Group + ";" + item.Semester + ";" + item.ActivityType + ";" + item.PlannedHours + ";" + item.ActualHours + ";" + item.StaffRate);
                    }

                    // Итоговая строка
                    writer.WriteLine();
                    writer.WriteLine("ИТОГО;;;Всего;;" + teacherItems.Sum(i => i.PlannedHours) + ";" + teacherItems.Sum(i => i.ActualHours));
                }

                MessageBox.Show("Статистика преподавателя экспортирована в CSV файл:\n" + filePath,
                    "Экспорт завершен", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при экспорте статистики в CSV: " + ex.Message,
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Обработчики событий
        private void BtnExportTeacherStats_Click(object sender, EventArgs e)
        {
            if (comboTeachers.SelectedItem == null)
            {
                MessageBox.Show("Выберите преподавателя", "Информация",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string selectedTeacher = comboTeachers.SelectedItem.ToString();
            string academicYear = comboAcademicYear.Text;

            if (string.IsNullOrEmpty(academicYear))
            {
                MessageBox.Show("Выберите учебный год", "Информация",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Создаем отчет по преподавателю
            ExportTeacherStatistics(selectedTeacher, academicYear);
        }

        private void ExportTeacherStatistics(string teacherName, string academicYear)
        {
            try
            {
                // Получаем данные преподавателя
                var teacherItems = _allItems
                    .Where(item => item.TeacherName == teacherName)
                    .ToList();

                if (teacherItems.Count == 0)
                {
                    MessageBox.Show("Нет данных для преподавателя " + teacherName,
                        "Информация", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                using (SaveFileDialog sfd = new SaveFileDialog())
                {
                    sfd.Filter = "Текстовые файлы (*.txt)|*.txt|CSV файлы (*.csv)|*.csv";
                    sfd.FileName = "Статистика_" + teacherName + "_" + academicYear + "_" + DateTime.Now.ToString("yyyyMMdd");

                    if (sfd.ShowDialog() == DialogResult.OK)
                    {
                        string extension = Path.GetExtension(sfd.FileName).ToLower();

                        if (extension == ".txt")
                        {
                            ExportTeacherStatsToTxt(teacherName, teacherItems, academicYear, sfd.FileName);
                        }
                        else if (extension == ".csv")
                        {
                            ExportTeacherStatsToCsv(teacherName, teacherItems, academicYear, sfd.FileName);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка экспорта: " + ex.Message, "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnUpdateStats_Click(object sender, EventArgs e)
        {
            UpdateTeacherHoursStatistics();
        }

        private void ComboTeachers_SelectedIndexChanged(object sender, EventArgs e)
        {
            UpdateTeacherHoursStatistics();
        }

        private void btnExportWord_Click(object sender, EventArgs e)
        {
            if (_allItems.Count == 0)
            {
                MessageBox.Show("Нет данных для экспорта", "Информация",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (SaveFileDialog sfd = new SaveFileDialog())
            {
                sfd.Filter = "Документы Word (*.docx)|*.docx|Документы Word 97-2003 (*.doc)|*.doc";
                sfd.FileName = "workload_data_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".docx";

                if (sfd.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        WordExporter.ExportToWord(_allItems, sfd.FileName);

                        if (MessageBox.Show("Документ успешно создан. Открыть его?", "Экспорт завершен",
                            MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            System.Diagnostics.Process.Start(sfd.FileName);
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Ошибка экспорта: " + ex.Message, "Ошибка",
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void BtnExportExcel_Click(object sender, EventArgs e)
        {
            if (_allItems.Count == 0)
            {
                MessageBox.Show("Нет данных для экспорта", "Информация",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (SaveFileDialog sfd = new SaveFileDialog())
            {
                sfd.Filter = "Excel файлы (*.xlsx)|*.xlsx";
                sfd.FileName = "workload_data_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".xlsx";

                if (sfd.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        ExcelExporter.ExportToExcel(_allItems, sfd.FileName);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Ошибка экспорта: " + ex.Message, "Ошибка",
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void btnLoadCsv_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog ofd = new OpenFileDialog())
            {
                ofd.Filter = "CSV файлы (*.csv)|*.csv";
                ofd.Multiselect = true;
                ofd.Title = "Выберите файлы с данными";

                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    LoadFiles(ofd.FileNames);
                }
            }
        }

        private void LoadFiles(string[] files)
        {
            int totalLoaded = 0;

            foreach (string file in files)
            {
                try
                {
                    List<WorkloadItem> items = WorkloadParser.ParseCsv(file);
                    _allItems.AddRange(items);
                    totalLoaded += items.Count;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(string.Format("Ошибка при загрузке {0}:\n{1}",
                        Path.GetFileName(file), ex.Message),
                        "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }

            UpdateDataGridView();

            MessageBox.Show(string.Format("Успешно загружено {0} записей из {1} файлов",
                totalLoaded, files.Length),
                "Информация", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnLoadFolder_Click(object sender, EventArgs e)
        {
            using (FolderBrowserDialog fbd = new FolderBrowserDialog())
            {
                fbd.Description = "Выберите папку с файлами данных";

                if (fbd.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        var items = WorkloadParser.LoadFromFolder(fbd.SelectedPath);
                        _allItems.AddRange(items);
                        UpdateDataGridView();

                        MessageBox.Show(string.Format("Загружено {0} записей из папки", items.Count),
                            "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(string.Format("Ошибка загрузки: {0}", ex.Message),
                            "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void btnLoadWord_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog ofd = new OpenFileDialog())
            {
                ofd.Filter = "Документы Word (*.doc;*.docx)|*.doc;*.docx";
                ofd.Multiselect = true;
                ofd.Title = "Выберите Word файлы";

                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    LoadWordFiles(ofd.FileNames);
                }
            }
        }

        private void LoadWordFiles(string[] files)
        {
            int totalLoaded = 0;

            foreach (string file in files)
            {
                try
                {
                    List<WorkloadItem> items = WorkloadParser.ParseWordDocument(file);
                    _allItems.AddRange(items);
                    totalLoaded += items.Count;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(string.Format("Ошибка при загрузке {0}:\n{1}",
                        Path.GetFileName(file), ex.Message),
                        "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }

            UpdateDataGridView();

            MessageBox.Show(string.Format("Успешно загружено {0} записей из {1} Word файлов",
                totalLoaded, files.Length),
                "Информация", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnExportCsv_Click(object sender, EventArgs e)
        {
            if (_allItems.Count == 0)
            {
                MessageBox.Show("Нет данных для экспорта", "Информация",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (SaveFileDialog sfd = new SaveFileDialog())
            {
                sfd.Filter = "CSV файлы (*.csv)|*.csv";
                sfd.FileName = "workload_data.csv";

                if (sfd.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        WorkloadParser.ExportToCsv(_allItems, sfd.FileName);
                        MessageBox.Show("Данные успешно экспортированы в CSV", "Успех",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(string.Format("Ошибка экспорта: {0}", ex.Message), "Ошибка",
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Очистить все загруженные данные?", "Подтверждение",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                _allItems.Clear();
                _items.Clear();
                UpdateStatistics();
                UpdateTeachersComboBox(); // Очищаем комбобокс преподавателей
                txtHoursSemester.Text = "0";
                txtHoursAcademicYear.Text = "0";

                if (_chartControl != null)
                {
                    _chartControl.Series.Clear();
                    _chartControl.Titles.Clear();
                    _chartControl.ChartAreas.Clear();
                }
            }
        }

        private void btnGenerateChart_Click(object sender, EventArgs e)
        {
            if (_allItems.Count == 0)
            {
                MessageBox.Show("Нет данных для анализа. Сначала загрузите файлы.",
                    "Информация", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                string chartType = comboChartType.SelectedItem != null ?
                    comboChartType.SelectedItem.ToString() : "";

                if (chartType.Contains("1."))
                    ShowChart1();
                else if (chartType.Contains("2."))
                    ShowChart2();
                else if (chartType.Contains("3."))
                    ShowChart3();
                else if (chartType.Contains("4."))
                    ShowChart4();
                else if (chartType.Contains("5."))
                    ShowChart5();
                else if (chartType.Contains("6."))
                    ShowChart6();
                else
                    MessageBox.Show("Выберите тип диаграммы", "Информация",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(string.Format("Ошибка построения графика:\n{0}", ex.Message), "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ShowChart1()
        {
            int year;
            if (!int.TryParse(comboYear.Text, out year))
            {
                MessageBox.Show("Выберите год", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            Dictionary<string, int> data = new Dictionary<string, int>();

            foreach (var item in _allItems)
            {
                if (item.AcademicYear == year && item.PlannedHours > 0)
                {
                    if (data.ContainsKey(item.ActivityType))
                        data[item.ActivityType] += item.PlannedHours;
                    else
                        data[item.ActivityType] = item.PlannedHours;
                }
            }

            var sorted = new List<KeyValuePair<string, int>>(data);
            sorted.Sort((x, y) => y.Value.CompareTo(x.Value));

            if (sorted.Count > 15)
                sorted = sorted.GetRange(0, 15);

            List<string> labels = new List<string>();
            List<int> values = new List<int>();

            foreach (var item in sorted)
            {
                labels.Add(item.Key);
                values.Add(item.Value);
            }

            DrawColumnChart(labels, values,
                string.Format("Нагрузка по видам занятий за {0} год", year),
                "Вид занятия", "Часы");
        }

        private void ShowChart2()
        {
            string academicYear = comboAcademicYear.Text;
            if (string.IsNullOrEmpty(academicYear))
            {
                MessageBox.Show("Выберите учебный год", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string[] parts = academicYear.Split('/');
            int startYear;
            if (parts.Length < 2 || !int.TryParse(parts[0], out startYear))
            {
                return;
            }

            Dictionary<string, int> data = new Dictionary<string, int>();

            foreach (var item in _allItems)
            {
                if (item.AcademicYear >= startYear &&
                    item.AcademicYear <= startYear + 1 &&
                    item.PlannedHours > 0)
                {
                    string activityType = item.ActivityType ?? "Не указано";
                    if (data.ContainsKey(activityType))
                    {
                        data[activityType] += item.PlannedHours;
                    }
                    else
                    {
                        data[activityType] = item.PlannedHours;
                    }
                }
            }

            if (data.Count == 0)
            {
                MessageBox.Show("Нет данных для построения графика", "Информация",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            var sorted = data.ToList();
            sorted.Sort((x, y) => y.Value.CompareTo(x.Value));

            if (sorted.Count > 15)
            {
                sorted = sorted.GetRange(0, 15);
            }

            List<string> labels = new List<string>();
            List<int> values = new List<int>();

            foreach (var item in sorted)
            {
                labels.Add(item.Key);
                values.Add(item.Value);
            }

            DrawColumnChart(labels, values,
                string.Format("Нагрузка по видам занятий за {0} учебный год", academicYear),
                "Вид занятия", "Часы");
        }

        private void ShowChart3()
        {
            string academicYear = comboAcademicYear.Text;
            if (string.IsNullOrEmpty(academicYear) || comboSemester.SelectedIndex < 0)
            {
                MessageBox.Show("Выберите учебный год и семестр", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string[] parts = academicYear.Split('/');
            int startYear;
            if (parts.Length < 2 || !int.TryParse(parts[0], out startYear))
                return;

            int semester = comboSemester.SelectedIndex + 1;
            int semesterYear = GetSemesterYear(startYear, semester);

            Dictionary<string, int> data = new Dictionary<string, int>();

            foreach (var item in _allItems)
            {
                if (item.AcademicYear == semesterYear &&
                    item.Semester == semester &&
                    item.PlannedHours > 0)
                {
                    if (data.ContainsKey(item.ActivityType))
                        data[item.ActivityType] += item.PlannedHours;
                    else
                        data[item.ActivityType] = item.PlannedHours;
                }
            }

            var sorted = new List<KeyValuePair<string, int>>(data);
            sorted.Sort((x, y) => y.Value.CompareTo(x.Value));

            if (sorted.Count > 15)
                sorted = sorted.GetRange(0, 15);

            List<string> labels = new List<string>();
            List<int> values = new List<int>();

            foreach (var item in sorted)
            {
                labels.Add(item.Key);
                values.Add(item.Value);
            }

            DrawColumnChart(labels, values,
                string.Format("Нагрузка по видам занятий за {0} семестр {1} уч.г.",
                    semester, academicYear),
                "Вид занятия", "Часы");
        }

        private void ShowChart4()
        {
            DateTime startDate = dtpStart.Value;
            DateTime endDate = dtpEnd.Value;

            if (startDate > endDate)
            {
                MessageBox.Show("Дата начала должна быть меньше даты окончания",
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            Dictionary<string, int> teacherHours = new Dictionary<string, int>();

            foreach (var item in _allItems)
            {
                if (item.AcademicYear >= startDate.Year && item.AcademicYear <= endDate.Year)
                {
                    string teacherName = item.TeacherName;
                    int hours = item.PlannedHours;

                    if (!string.IsNullOrEmpty(teacherName))
                    {
                        if (teacherHours.ContainsKey(teacherName))
                            teacherHours[teacherName] += hours;
                        else
                            teacherHours[teacherName] = hours;
                    }
                }
            }

            if (teacherHours.Count == 0)
            {
                MessageBox.Show("Не найдено данных за указанный период", "Информация",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            var sorted = new List<KeyValuePair<string, int>>(teacherHours);
            sorted.Sort((x, y) => y.Value.CompareTo(x.Value));

            int maxItems = 15;
            if (sorted.Count > maxItems)
                sorted = sorted.GetRange(0, maxItems);

            List<string> labels = new List<string>();
            List<int> values = new List<int>();

            foreach (var item in sorted)
            {
                labels.Add(item.Key);
                values.Add(item.Value);
            }

            DrawColumnChart(labels, values,
                string.Format("Нагрузка преподавателей за период {0:dd.MM.yyyy} - {1:dd.MM.yyyy}",
                    startDate, endDate),
                "Преподаватель", "Часы нагрузки");
        }

        private void ShowChart5()
        {
            string academicYear = comboAcademicYear.Text;
            if (string.IsNullOrEmpty(academicYear))
                return;

            string[] parts = academicYear.Split('/');
            int startYear;
            if (parts.Length < 2 || !int.TryParse(parts[0], out startYear))
                return;

            Dictionary<string, WorkloadItem> teachers = new Dictionary<string, WorkloadItem>();
            foreach (var item in _allItems)
            {
                if ((item.AcademicYear == startYear || item.AcademicYear == startYear + 1) &&
                    !string.IsNullOrEmpty(item.TeacherName))
                {
                    if (!teachers.ContainsKey(item.TeacherName))
                        teachers.Add(item.TeacherName, item);
                }
            }

            Dictionary<string, int> rateGroups = new Dictionary<string, int>();

            foreach (var teacher in teachers.Values)
            {
                string rateGroup;
                if (teacher.StaffRate >= 1.0m)
                    rateGroup = "Полная ставка";
                else if (teacher.StaffRate >= 0.75m)
                    rateGroup = "0.75 ставки";
                else if (teacher.StaffRate >= 0.5m)
                    rateGroup = "0.5 ставки";
                else
                    rateGroup = "0.25 ставки";

                if (rateGroups.ContainsKey(rateGroup))
                    rateGroups[rateGroup]++;
                else
                    rateGroups.Add(rateGroup, 1);
            }

            var sorted = new List<KeyValuePair<string, int>>(rateGroups);
            sorted.Sort((x, y) => y.Value.CompareTo(x.Value));

            List<string> labels = new List<string>();
            List<int> values = new List<int>();

            foreach (var item in sorted)
            {
                labels.Add(item.Key);
                values.Add(item.Value);
            }

            DrawColumnChart(labels, values,
                string.Format("Распределение ставок преподавателей за {0} уч.г.", academicYear),
                "Тип ставки", "Количество преподавателей");
        }

        private void ShowChart6()
        {
            string academicYear = comboAcademicYear.Text;
            if (string.IsNullOrEmpty(academicYear))
                return;

            string[] parts = academicYear.Split('/');
            int startYear;
            if (parts.Length < 2 || !int.TryParse(parts[0], out startYear))
                return;

            Dictionary<string, bool> teachers = new Dictionary<string, bool>();
            int mainCount = 0;
            int externalCount = 0;

            foreach (var item in _allItems)
            {
                if ((item.AcademicYear == startYear || item.AcademicYear == startYear + 1) &&
                    !string.IsNullOrEmpty(item.TeacherName))
                {
                    if (!teachers.ContainsKey(item.TeacherName))
                    {
                        teachers.Add(item.TeacherName, item.IsExternal);

                        if (item.IsExternal)
                            externalCount++;
                        else
                            mainCount++;
                    }
                }
            }

            DrawColumnChart(
                new List<string> { "Основные сотрудники", "Совместители" },
                new List<int> { mainCount, externalCount },
                string.Format("Состав преподавателей за {0} уч.г.", academicYear),
                "Тип занятости", "Количество преподавателей"
            );
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
        }

        private void MainForm_Load_1(object sender, EventArgs e)
        {
        }

        private void dataGridView_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex >= 0 && e.RowIndex >= 0)
            {
                var columnName = dataGridView.Columns[e.ColumnIndex].DataPropertyName;

                if (columnName == "ActualHours")
                {
                    var editedItem = _items[e.RowIndex];

                    var originalItem = _allItems.FirstOrDefault(item =>
                        item.TeacherName == editedItem.TeacherName &&
                        item.Discipline == editedItem.Discipline &&
                        item.AcademicYear == editedItem.AcademicYear &&
                        item.Semester == item.Semester);

                    if (originalItem != null)
                    {
                        if (dataGridView.Rows[e.RowIndex].Cells[e.ColumnIndex].Value != null)
                        {
                            string value = dataGridView.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString();
                            int actualHours;

                            if (int.TryParse(value, out actualHours))
                            {
                                originalItem.ActualHours = actualHours;
                                editedItem.ActualHours = actualHours;

                                UpdateStatistics();
                                dataGridView.InvalidateRow(e.RowIndex);
                            }
                            else
                            {
                                MessageBox.Show("Введите целое число для фактических часов", "Ошибка",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                                dataGridView.Rows[e.RowIndex].Cells[e.ColumnIndex].Value = originalItem.ActualHours;
                            }
                        }
                    }
                }
            }
        }

        private void dataGridView_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
            {
                var columnName = dataGridView.Columns[e.ColumnIndex].DataPropertyName;

                if (columnName == "StaffRate" && e.Value != null)
                {
                    if (decimal.TryParse(e.Value.ToString(), out decimal rate))
                    {
                        e.Value = rate.ToString("0.0");
                        e.FormattingApplied = true;
                    }
                }
            }
        }
    }

    // Класс для экспорта в Excel
    public static class ExcelExporter
    {
        public static void ExportToExcel(List<WorkloadItem> items, string filePath)
        {
            try
            {
                Excel.Application excelApp = null;
                Excel.Workbook workbook = null;
                Excel.Worksheet worksheet = null;

                try
                {
                    excelApp = new Excel.Application();
                    excelApp.Visible = false;
                    workbook = excelApp.Workbooks.Add();
                    worksheet = (Excel.Worksheet)workbook.Worksheets[1];

                    // Заголовки - только 13 столбцов
                    worksheet.Cells[1, 1] = "ФИО преподавателя";
                    worksheet.Cells[1, 2] = "Должность";
                    worksheet.Cells[1, 3] = "Ученая степень";
                    worksheet.Cells[1, 4] = "Ученое звание";
                    worksheet.Cells[1, 5] = "Ставка";
                    worksheet.Cells[1, 6] = "Тип занятости";
                    worksheet.Cells[1, 7] = "Учебный год";
                    worksheet.Cells[1, 8] = "Семестр";
                    worksheet.Cells[1, 9] = "Дисциплина";
                    worksheet.Cells[1, 10] = "Группа";
                    worksheet.Cells[1, 11] = "Вид занятия";
                    worksheet.Cells[1, 12] = "Запланировано часов";
                    worksheet.Cells[1, 13] = "Фактически часов";

                    // Форматирование заголовков - только до M (13 столбцов)
                    Excel.Range headerRange = worksheet.Range["A1:M1"];
                    headerRange.Font.Bold = true;
                    headerRange.Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.LightBlue);
                    headerRange.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;

                    // Заполнение данных
                    int row = 2;
                    foreach (var item in items)
                    {
                        worksheet.Cells[row, 1] = item.TeacherName;
                        worksheet.Cells[row, 2] = item.Position;
                        worksheet.Cells[row, 3] = item.AcademicDegree;
                        worksheet.Cells[row, 4] = item.AcademicTitle;
                        worksheet.Cells[row, 5] = item.StaffRate;
                        worksheet.Cells[row, 6] = item.EmploymentType;
                        worksheet.Cells[row, 7] = item.AcademicYear;
                        worksheet.Cells[row, 8] = item.Semester;
                        worksheet.Cells[row, 9] = item.Discipline;
                        worksheet.Cells[row, 10] = item.Group;
                        worksheet.Cells[row, 11] = item.ActivityType;
                        worksheet.Cells[row, 12] = item.PlannedHours;
                        worksheet.Cells[row, 13] = item.ActualHours;
                        row++;
                    }

                    // Автоматическое выравнивание столбцов - только до M
                    Excel.Range dataRange = worksheet.Range["A1:M" + (row - 1)];
                    dataRange.Columns.AutoFit();

                    // Добавляем итоговую строку
                    worksheet.Cells[row, 1] = "ИТОГО:";
                    worksheet.Cells[row, 12] = items.Sum(i => i.PlannedHours);
                    worksheet.Cells[row, 13] = items.Sum(i => i.ActualHours);

                    Excel.Range totalRange = worksheet.Range["A" + row + ":M" + row];
                    totalRange.Font.Bold = true;
                    totalRange.Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.LightGreen);

                    workbook.SaveAs(filePath);
                    MessageBox.Show("Данные успешно экспортированы в Excel файл:\n" + filePath,
                        "Экспорт завершен", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    throw new Exception("Ошибка при экспорте в Excel: " + ex.Message);
                }
                finally
                {
                    if (workbook != null)
                    {
                        workbook.Close(false);
                        Marshal.ReleaseComObject(workbook);
                    }
                    if (excelApp != null)
                    {
                        excelApp.Quit();
                        Marshal.ReleaseComObject(excelApp);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при создании Excel файла: " + ex.Message,
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}