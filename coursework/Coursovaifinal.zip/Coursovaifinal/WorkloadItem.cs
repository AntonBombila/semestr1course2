﻿using System;

namespace CourseWorkApp
{
    public class WorkloadItem
    {
        public string TeacherName { get; set; }
        public string Position { get; set; }
        public string AcademicDegree { get; set; }
        public string AcademicTitle { get; set; }
        public decimal StaffRate { get; set; }
        public string EmploymentType { get; set; }
        public int AcademicYear { get; set; }
        public int Semester { get; set; }
        public string Discipline { get; set; }
        public string Group { get; set; }
        public string ActivityType { get; set; }
        public int PlannedHours { get; set; }
        public int ActualHours { get; set; }
        public bool IsExternal { get; set; }

        // Конструктор
        public WorkloadItem()
        {
            // По умолчанию фактические часы = 0
            ActualHours = 0;
        }

        // Добавляем свойство для отображения в DataGridView
        public string IsExternalDisplay
        {
            get { return IsExternal ? "Да" : "Нет"; }
        }

        public override string ToString()
        {
            return string.Format("{0} - {1} ({2}): План {3}ч, Факт {4}ч",
                TeacherName, Discipline, ActivityType, PlannedHours, ActualHours);
        }
    }
}