﻿namespace CourseWorkApp
{
    partial class MainForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panelLeft = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.dtpEnd = new System.Windows.Forms.DateTimePicker();
            this.label6 = new System.Windows.Forms.Label();
            this.dtpStart = new System.Windows.Forms.DateTimePicker();
            this.label4 = new System.Windows.Forms.Label();
            this.comboChartType = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.comboSemester = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.comboAcademicYear = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.comboYear = new System.Windows.Forms.ComboBox();
            this.panelButtons = new System.Windows.Forms.Panel();
            this.btnExportWord = new System.Windows.Forms.Button();
            this.btnExportExcel = new System.Windows.Forms.Button();
            this.btnLoadWord = new System.Windows.Forms.Button();
            this.btnGenerateChart = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnExportCsv = new System.Windows.Forms.Button();
            this.btnLoadFolder = new System.Windows.Forms.Button();
            this.btnLoadCsv = new System.Windows.Forms.Button();
            this.panelMain = new System.Windows.Forms.Panel();
            this.chartWorkload = new System.Windows.Forms.Panel();
            this.dataGridView = new System.Windows.Forms.DataGridView();
            this.panelStats = new System.Windows.Forms.Panel();
            this.lblTotalTeachers = new System.Windows.Forms.Label();
            this.lblTotalRecords = new System.Windows.Forms.Label();
            this.panelLeft.SuspendLayout();
            this.panelButtons.SuspendLayout();
            this.panelMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).BeginInit();
            this.panelStats.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelLeft
            // 
            this.panelLeft.Controls.Add(this.label7);
            this.panelLeft.Controls.Add(this.dtpEnd);
            this.panelLeft.Controls.Add(this.label6);
            this.panelLeft.Controls.Add(this.dtpStart);
            this.panelLeft.Controls.Add(this.label4);
            this.panelLeft.Controls.Add(this.comboChartType);
            this.panelLeft.Controls.Add(this.label3);
            this.panelLeft.Controls.Add(this.comboSemester);
            this.panelLeft.Controls.Add(this.label2);
            this.panelLeft.Controls.Add(this.comboAcademicYear);
            this.panelLeft.Controls.Add(this.label1);
            this.panelLeft.Controls.Add(this.comboYear);
            this.panelLeft.Controls.Add(this.panelButtons);
            this.panelLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelLeft.Location = new System.Drawing.Point(0, 0);
            this.panelLeft.Margin = new System.Windows.Forms.Padding(6);
            this.panelLeft.Name = "panelLeft";
            this.panelLeft.Size = new System.Drawing.Size(700, 1538);
            this.panelLeft.TabIndex = 0;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(40, 706);
            this.label7.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(133, 25);
            this.label7.TabIndex = 14;
            this.label7.Text = "Дата конца:";
            // 
            // dtpEnd
            // 
            this.dtpEnd.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpEnd.Location = new System.Drawing.Point(40, 745);
            this.dtpEnd.Margin = new System.Windows.Forms.Padding(6);
            this.dtpEnd.Name = "dtpEnd";
            this.dtpEnd.Size = new System.Drawing.Size(596, 31);
            this.dtpEnd.TabIndex = 13;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(40, 591);
            this.label6.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(145, 25);
            this.label6.TabIndex = 12;
            this.label6.Text = "Дата начала:";
            // 
            // dtpStart
            // 
            this.dtpStart.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpStart.Location = new System.Drawing.Point(40, 629);
            this.dtpStart.Margin = new System.Windows.Forms.Padding(6);
            this.dtpStart.Name = "dtpStart";
            this.dtpStart.Size = new System.Drawing.Size(596, 31);
            this.dtpStart.TabIndex = 11;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(40, 462);
            this.label4.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(145, 25);
            this.label4.TabIndex = 8;
            this.label4.Text = "Тип графика:";
            // 
            // comboChartType
            // 
            this.comboChartType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboChartType.FormattingEnabled = true;
            this.comboChartType.Location = new System.Drawing.Point(40, 500);
            this.comboChartType.Margin = new System.Windows.Forms.Padding(6);
            this.comboChartType.Name = "comboChartType";
            this.comboChartType.Size = new System.Drawing.Size(596, 33);
            this.comboChartType.TabIndex = 7;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(40, 346);
            this.label3.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(105, 25);
            this.label3.TabIndex = 6;
            this.label3.Text = "Семестр:";
            // 
            // comboSemester
            // 
            this.comboSemester.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboSemester.FormattingEnabled = true;
            this.comboSemester.Location = new System.Drawing.Point(40, 385);
            this.comboSemester.Margin = new System.Windows.Forms.Padding(6);
            this.comboSemester.Name = "comboSemester";
            this.comboSemester.Size = new System.Drawing.Size(596, 33);
            this.comboSemester.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(40, 231);
            this.label2.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(143, 25);
            this.label2.TabIndex = 4;
            this.label2.Text = "Учебный год:";
            // 
            // comboAcademicYear
            // 
            this.comboAcademicYear.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboAcademicYear.FormattingEnabled = true;
            this.comboAcademicYear.Location = new System.Drawing.Point(40, 269);
            this.comboAcademicYear.Margin = new System.Windows.Forms.Padding(6);
            this.comboAcademicYear.Name = "comboAcademicYear";
            this.comboAcademicYear.Size = new System.Drawing.Size(596, 33);
            this.comboAcademicYear.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(40, 115);
            this.label1.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(193, 25);
            this.label1.TabIndex = 2;
            this.label1.Text = "Календарный год:";
            // 
            // comboYear
            // 
            this.comboYear.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboYear.FormattingEnabled = true;
            this.comboYear.Location = new System.Drawing.Point(40, 154);
            this.comboYear.Margin = new System.Windows.Forms.Padding(6);
            this.comboYear.Name = "comboYear";
            this.comboYear.Size = new System.Drawing.Size(596, 33);
            this.comboYear.TabIndex = 1;
            // 
            // panelButtons
            // 
            this.panelButtons.Controls.Add(this.btnExportWord);
            this.panelButtons.Controls.Add(this.btnExportExcel);
            this.panelButtons.Controls.Add(this.btnLoadWord);
            this.panelButtons.Controls.Add(this.btnGenerateChart);
            this.panelButtons.Controls.Add(this.btnClear);
            this.panelButtons.Controls.Add(this.btnExportCsv);
            this.panelButtons.Controls.Add(this.btnLoadFolder);
            this.panelButtons.Controls.Add(this.btnLoadCsv);
            this.panelButtons.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelButtons.Location = new System.Drawing.Point(0, 838);
            this.panelButtons.Margin = new System.Windows.Forms.Padding(6);
            this.panelButtons.Name = "panelButtons";
            this.panelButtons.Size = new System.Drawing.Size(700, 700);
            this.panelButtons.TabIndex = 0;
            // 
            // btnExportWord
            // 
            this.btnExportWord.Location = new System.Drawing.Point(40, 442);
            this.btnExportWord.Margin = new System.Windows.Forms.Padding(6);
            this.btnExportWord.Name = "btnExportWord";
            this.btnExportWord.Size = new System.Drawing.Size(600, 67);
            this.btnExportWord.TabIndex = 7;
            this.btnExportWord.Text = "Экспорт в Word";
            this.btnExportWord.UseVisualStyleBackColor = true;
            // 
            // btnExportExcel
            // 
            this.btnExportExcel.Location = new System.Drawing.Point(40, 360);
            this.btnExportExcel.Margin = new System.Windows.Forms.Padding(6);
            this.btnExportExcel.Name = "btnExportExcel";
            this.btnExportExcel.Size = new System.Drawing.Size(600, 67);
            this.btnExportExcel.TabIndex = 6;
            this.btnExportExcel.Text = "Экспорт в Excel";
            this.btnExportExcel.UseVisualStyleBackColor = true;
            // 
            // btnLoadWord
            // 
            this.btnLoadWord.Location = new System.Drawing.Point(340, 192);
            this.btnLoadWord.Margin = new System.Windows.Forms.Padding(6);
            this.btnLoadWord.Name = "btnLoadWord";
            this.btnLoadWord.Size = new System.Drawing.Size(300, 67);
            this.btnLoadWord.TabIndex = 5;
            this.btnLoadWord.Text = "Импорт Word ";
            this.btnLoadWord.UseVisualStyleBackColor = true;
            // 
            // btnGenerateChart
            // 
            this.btnGenerateChart.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold);
            this.btnGenerateChart.Location = new System.Drawing.Point(40, 271);
            this.btnGenerateChart.Margin = new System.Windows.Forms.Padding(6);
            this.btnGenerateChart.Name = "btnGenerateChart";
            this.btnGenerateChart.Size = new System.Drawing.Size(600, 77);
            this.btnGenerateChart.TabIndex = 4;
            this.btnGenerateChart.Text = "Построить график";
            this.btnGenerateChart.UseVisualStyleBackColor = true;
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(40, 525);
            this.btnClear.Margin = new System.Windows.Forms.Padding(6);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(600, 67);
            this.btnClear.TabIndex = 3;
            this.btnClear.Text = "Очистить данные";
            this.btnClear.UseVisualStyleBackColor = true;
            // 
            // btnExportCsv
            // 
            this.btnExportCsv.Location = new System.Drawing.Point(40, 192);
            this.btnExportCsv.Margin = new System.Windows.Forms.Padding(6);
            this.btnExportCsv.Name = "btnExportCsv";
            this.btnExportCsv.Size = new System.Drawing.Size(300, 67);
            this.btnExportCsv.TabIndex = 2;
            this.btnExportCsv.Text = "Экспорт в CSV";
            this.btnExportCsv.UseVisualStyleBackColor = true;
            // 
            // btnLoadFolder
            // 
            this.btnLoadFolder.Location = new System.Drawing.Point(340, 96);
            this.btnLoadFolder.Margin = new System.Windows.Forms.Padding(6);
            this.btnLoadFolder.Name = "btnLoadFolder";
            this.btnLoadFolder.Size = new System.Drawing.Size(300, 67);
            this.btnLoadFolder.TabIndex = 1;
            this.btnLoadFolder.Text = "Импорт Папки с CSV/Word";
            this.btnLoadFolder.UseVisualStyleBackColor = true;
            // 
            // btnLoadCsv
            // 
            this.btnLoadCsv.Location = new System.Drawing.Point(40, 96);
            this.btnLoadCsv.Margin = new System.Windows.Forms.Padding(6);
            this.btnLoadCsv.Name = "btnLoadCsv";
            this.btnLoadCsv.Size = new System.Drawing.Size(300, 67);
            this.btnLoadCsv.TabIndex = 0;
            this.btnLoadCsv.Text = "Импорт CSV";
            this.btnLoadCsv.UseVisualStyleBackColor = true;
            // 
            // panelMain
            // 
            this.panelMain.Controls.Add(this.chartWorkload);
            this.panelMain.Controls.Add(this.dataGridView);
            this.panelMain.Controls.Add(this.panelStats);
            this.panelMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelMain.Location = new System.Drawing.Point(700, 0);
            this.panelMain.Margin = new System.Windows.Forms.Padding(6);
            this.panelMain.Name = "panelMain";
            this.panelMain.Size = new System.Drawing.Size(1700, 1538);
            this.panelMain.TabIndex = 1;
            // 
            // chartWorkload
            // 
            this.chartWorkload.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chartWorkload.Location = new System.Drawing.Point(0, 1344);
            this.chartWorkload.Margin = new System.Windows.Forms.Padding(6);
            this.chartWorkload.Name = "chartWorkload";
            this.chartWorkload.Size = new System.Drawing.Size(1700, 194);
            this.chartWorkload.TabIndex = 2;
            // 
            // dataGridView
            // 
            this.dataGridView.AllowUserToAddRows = false;
            this.dataGridView.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.dataGridView.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView.Dock = System.Windows.Forms.DockStyle.Top;
            this.dataGridView.Location = new System.Drawing.Point(0, 77);
            this.dataGridView.Margin = new System.Windows.Forms.Padding(6);
            this.dataGridView.Name = "dataGridView";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView.RowHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView.RowHeadersWidth = 50;
            this.dataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView.Size = new System.Drawing.Size(1700, 1267);
            this.dataGridView.TabIndex = 1;
            // 
            // panelStats
            // 
            this.panelStats.Controls.Add(this.lblTotalTeachers);
            this.panelStats.Controls.Add(this.lblTotalRecords);
            this.panelStats.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelStats.Location = new System.Drawing.Point(0, 0);
            this.panelStats.Margin = new System.Windows.Forms.Padding(6);
            this.panelStats.Name = "panelStats";
            this.panelStats.Size = new System.Drawing.Size(1700, 77);
            this.panelStats.TabIndex = 0;
            // 
            // lblTotalTeachers
            // 
            this.lblTotalTeachers.AutoSize = true;
            this.lblTotalTeachers.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.lblTotalTeachers.Location = new System.Drawing.Point(600, 19);
            this.lblTotalTeachers.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblTotalTeachers.Name = "lblTotalTeachers";
            this.lblTotalTeachers.Size = new System.Drawing.Size(235, 29);
            this.lblTotalTeachers.TabIndex = 1;
            this.lblTotalTeachers.Text = "Преподавателей: 0";
            // 
            // lblTotalRecords
            // 
            this.lblTotalRecords.AutoSize = true;
            this.lblTotalRecords.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.lblTotalRecords.Location = new System.Drawing.Point(40, 19);
            this.lblTotalRecords.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblTotalRecords.Name = "lblTotalRecords";
            this.lblTotalRecords.Size = new System.Drawing.Size(208, 29);
            this.lblTotalRecords.TabIndex = 0;
            this.lblTotalRecords.Text = "Всего записей: 0";
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(2400, 1538);
            this.Controls.Add(this.panelMain);
            this.Controls.Add(this.panelLeft);
            this.Margin = new System.Windows.Forms.Padding(6);
            this.MinimumSize = new System.Drawing.Size(1774, 1088);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Анализ учебной нагрузки преподавателей";
            this.Load += new System.EventHandler(this.MainForm_Load_1);
            this.panelLeft.ResumeLayout(false);
            this.panelLeft.PerformLayout();
            this.panelButtons.ResumeLayout(false);
            this.panelMain.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).EndInit();
            this.panelStats.ResumeLayout(false);
            this.panelStats.PerformLayout();
            this.ResumeLayout(false);

        }

        private System.Windows.Forms.Panel panelLeft;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DateTimePicker dtpEnd;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DateTimePicker dtpStart;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox comboChartType;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox comboSemester;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox comboAcademicYear;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboYear;
        private System.Windows.Forms.Panel panelButtons;
        private System.Windows.Forms.Button btnExportWord;
        private System.Windows.Forms.Button btnExportExcel;
        private System.Windows.Forms.Button btnLoadWord;
        private System.Windows.Forms.Button btnGenerateChart;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnExportCsv;
        private System.Windows.Forms.Button btnLoadFolder;
        private System.Windows.Forms.Button btnLoadCsv;
        private System.Windows.Forms.Panel panelMain;
        private System.Windows.Forms.Panel chartWorkload;
        private System.Windows.Forms.DataGridView dataGridView;
        private System.Windows.Forms.Panel panelStats;
        private System.Windows.Forms.Label lblTotalTeachers;
        private System.Windows.Forms.Label lblTotalRecords;
    }
}