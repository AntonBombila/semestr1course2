﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Word = Microsoft.Office.Interop.Word;
using Excel = Microsoft.Office.Interop.Excel;
using System.Drawing;

namespace CourseWorkApp
{
    public static class WorkloadParser
    {
        private static Random _random = new Random();

        public static List<WorkloadItem> ParseWordDocument(string filePath)
        {
            var items = new List<WorkloadItem>();

            Word.Application wordApp = null;
            Word.Document doc = null;

            try
            {
                wordApp = new Word.Application();
                wordApp.Visible = false;
                doc = wordApp.Documents.Open(filePath, ReadOnly: true);

                // Получаем информацию о преподавателе
                string teacherName = ExtractTeacherNameFromWord(doc, Path.GetFileNameWithoutExtension(filePath));
                string position = ExtractPositionFromWord(doc);
                string degree = ExtractAcademicDegreeFromWord(doc);
                string title = ExtractAcademicTitleFromWord(doc);
                decimal staffRate = ExtractStaffRateFromWord(doc);
                bool isExternal = DetermineEmploymentTypeFromWord(doc);
                string employmentType = isExternal ? "Совместитель" : "Основной";

                // Получаем начало учебного года
                int academicYearStart = ExtractYearFromFileName(filePath);

                Console.WriteLine($"\n=== ПАРСИНГ ДОКУМЕНТА: {Path.GetFileName(filePath)} ===");
                Console.WriteLine($"Преподаватель: {teacherName}");
                Console.WriteLine($"Начало учебного года: {academicYearStart}/{academicYearStart + 1}");
                Console.WriteLine($"Таблиц в документе: {doc.Tables.Count}");

                // Ищем все таблицы нагрузки
                int workloadTableCount = 0;
                for (int tableIndex = 1; tableIndex <= doc.Tables.Count; tableIndex++)
                {
                    var table = doc.Tables[tableIndex];

                    // Простая проверка на таблицу нагрузки
                    if (IsWorkloadTable(table))
                    {
                        workloadTableCount++;
                        Console.WriteLine($"✓ Найдена таблица нагрузки #{workloadTableCount}");

                        // Определяем семестр для этой таблицы
                        int currentSemester = DetermineSemesterFromTable(table);
                        if (currentSemester == 0)
                        {
                            currentSemester = workloadTableCount; // 1 для первой таблицы, 2 для второй
                        }
                        Console.WriteLine($"  Семестр для этой таблицы: {currentSemester}");

                        // Парсим таблицу
                        ParseWorkloadTableSimple(table, items, teacherName, position, degree, title,
                                                 staffRate, employmentType, isExternal, academicYearStart, currentSemester);
                    }
                }

                Console.WriteLine($"\nНайдено таблиц нагрузки: {workloadTableCount}");

                // Если не нашли таблиц, пробуем найти любые данные
                if (items.Count == 0)
                {
                    Console.WriteLine("\n⚠ Стандартный парсинг не дал результатов, пробуем найти любые данные...");
                    ParseAllTablesSimple(doc, items, teacherName, position, degree, title,
                                         staffRate, employmentType, isExternal, academicYearStart);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Ошибка при чтении Word файла: {ex.Message}");
                MessageBox.Show($"Ошибка при чтении Word файла:\n{ex.Message}",
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (doc != null)
                {
                    doc.Close(false);
                    Marshal.ReleaseComObject(doc);
                }
                if (wordApp != null)
                {
                    wordApp.Quit(false);
                    Marshal.ReleaseComObject(wordApp);
                }
            }

            // Статистика
            PrintParsingStatistics(items);

            return items;
        }

        // Простая проверка таблицы нагрузки
        private static bool IsWorkloadTable(Word.Table table)
        {
            if (table.Rows.Count < 3 || table.Columns.Count < 3)
                return false;

            // Проверяем первые строки на наличие ключевых слов
            try
            {
                // Проверяем первые 5 строк
                for (int row = 1; row <= Math.Min(5, table.Rows.Count); row++)
                {
                    string rowText = "";
                    for (int col = 1; col <= Math.Min(3, table.Columns.Count); col++)
                    {
                        rowText += GetCellText(table, row, col).ToLower() + " ";
                    }

                    // Ключевые слова, указывающие на таблицу нагрузки
                    if (rowText.Contains("дисциплин") || rowText.Contains("вид занятий") ||
                        rowText.Contains("группа") || rowText.Contains("объединение") ||
                        rowText.Contains("час") || rowText.Contains("семестр") ||
                        rowText.Contains("лекция") || rowText.Contains("практика"))
                    {
                        return true;
                    }
                }
            }
            catch { }

            return false;
        }

        // Простой метод парсинга таблицы
        private static void ParseWorkloadTableSimple(Word.Table table, List<WorkloadItem> items,
            string teacherName, string position, string degree, string title,
            decimal staffRate, string employmentType, bool isExternal, int academicYearStart, int currentSemester)
        {
            Console.WriteLine($"\n=== ПАРСИНГ ТАБЛИЦЫ (Семестр {currentSemester}) ===");

            // Ищем строку с заголовками
            int startRow = 1;
            for (int row = 1; row <= Math.Min(5, table.Rows.Count); row++)
            {
                string cell1 = GetCellText(table, row, 1).ToLower();
                if (cell1.Contains("дисциплин") || cell1.Contains("наименование"))
                {
                    startRow = row + 1; // Начинаем со следующей строки после заголовка
                    break;
                }
            }

            string currentDiscipline = "";

            for (int row = startRow; row <= table.Rows.Count; row++)
            {
                try
                {
                    string disciplineCell = GetCellText(table, row, 1);
                    string groupCell = GetCellText(table, row, 2);
                    string activityCell = GetCellText(table, row, 3);
                    string hoursCell = table.Columns.Count >= 4 ? GetCellText(table, row, 4) : "";

                    // Пропускаем пустые строки
                    if (string.IsNullOrEmpty(disciplineCell) &&
                        string.IsNullOrEmpty(groupCell) &&
                        string.IsNullOrEmpty(activityCell) &&
                        string.IsNullOrEmpty(hoursCell))
                        continue;

                    // Пропускаем заголовки и итоги
                    if (disciplineCell.Contains("Наименование дисциплин") ||
                        disciplineCell.Contains("Всего часов") ||
                        disciplineCell.Contains("Итого:") ||
                        disciplineCell.ToLower().Contains("семестр"))
                        continue;

                    // ОБРАБОТКА ДИСЦИПЛИНЫ
                    if (!string.IsNullOrEmpty(disciplineCell) &&
                        !disciplineCell.Contains("Всего") &&
                        !disciplineCell.Contains("---") &&
                        disciplineCell.Length > 2)
                    {
                        string cleanedDiscipline = CleanDisciplineName(disciplineCell);
                        if (!string.IsNullOrEmpty(cleanedDiscipline))
                        {
                            currentDiscipline = cleanedDiscipline;
                        }
                    }

                    // ОБРАБОТКА ВИДА ЗАНЯТИЯ И ЧАСОВ
                    if (!string.IsNullOrEmpty(activityCell) &&
                        !string.IsNullOrEmpty(hoursCell) &&
                        !string.IsNullOrEmpty(currentDiscipline))
                    {
                        string activityType = NormalizeActivityType(activityCell);
                        int plannedHours = ParseInt(hoursCell);

                        if (plannedHours > 0 && !string.IsNullOrEmpty(activityType))
                        {
                            // Определяем правильный год для записи
                            int recordYear = currentSemester == 1 ? academicYearStart : academicYearStart + 1;

                            
                            int actualHours = 0;

                            var item = new WorkloadItem
                            {
                                TeacherName = CleanText(teacherName),
                                Position = CleanText(position),
                                AcademicDegree = CleanText(degree),
                                AcademicTitle = CleanText(title),
                                StaffRate = staffRate,
                                EmploymentType = employmentType,
                                IsExternal = isExternal,
                                AcademicYear = recordYear,
                                Semester = currentSemester,
                                Discipline = currentDiscipline,
                                Group = ExtractGroupCode(groupCell),
                                ActivityType = activityType,
                                PlannedHours = plannedHours,
                                ActualHours = actualHours
                            };

                            items.Add(item);

                            Console.WriteLine($"  ✓ Добавлено: {currentDiscipline} | {activityType} | План: {plannedHours}ч, Факт: {actualHours}ч");
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"❌ Ошибка в строке {row}: {ex.Message}");
                    continue;
                }
            }
        }


        // Простой парсинг всех таблиц
        private static void ParseAllTablesSimple(Word.Document doc, List<WorkloadItem> items,
            string teacherName, string position, string degree, string title,
            decimal staffRate, string employmentType, bool isExternal, int academicYearStart)
        {
            Console.WriteLine("\n=== ПРОСТОЙ ПАРСИНГ ВСЕХ ТАБЛИЦ ===");

            int tableNum = 0;
            foreach (Word.Table table in doc.Tables)
            {
                tableNum++;
                Console.WriteLine($"\n--- Таблица {tableNum}: {table.Rows.Count} строк, {table.Columns.Count} столбцов ---");

                // Если таблица слишком маленькая, пропускаем
                if (table.Rows.Count < 2 || table.Columns.Count < 3)
                    continue;

                // Пробуем найти данные
                for (int row = 1; row <= table.Rows.Count; row++)
                {
                    try
                    {
                        // Проверяем разные комбинации столбцов
                        for (int colOffset = 0; colOffset <= 2; colOffset++)
                        {
                            if (table.Columns.Count >= colOffset + 3)
                            {
                                string cell1 = GetCellText(table, row, 1 + colOffset);
                                string cell2 = GetCellText(table, row, 2 + colOffset);
                                string cell3 = GetCellText(table, row, 3 + colOffset);

                                // Пробуем распарсить как данные нагрузки
                                TryParseAsWorkload(cell1, cell2, cell3, items, teacherName, position,
                                                   degree, title, staffRate, employmentType, isExternal,
                                                   academicYearStart, 1); // Предполагаем 1 семестр
                            }
                        }
                    }
                    catch { }
                }
            }
        }

        private static void TryParseAsWorkload(string cell1, string cell2, string cell3,
            List<WorkloadItem> items, string teacherName, string position,
            string degree, string title, decimal staffRate, string employmentType,
            bool isExternal, int academicYearStart, int semester)
        {
            // Пробуем разные варианты интерпретации
            string[] cells = new[] { cell1, cell2, cell3 };

            // Вариант 1: cell1 - дисциплина, cell2 - группа, cell3 - часы
            if (!string.IsNullOrEmpty(cell1) && cell1.Length > 2 &&
                !cell1.ToLower().Contains("всего") && !cell1.Contains(":"))
            {
                int hours = ParseInt(cell3);
                if (hours > 0)
                {
                    string activityType = NormalizeActivityType(cell2.Contains("-") ? "" : cell2);

                    var item = new WorkloadItem
                    {
                        TeacherName = CleanText(teacherName),
                        Position = CleanText(position),
                        AcademicDegree = CleanText(degree),
                        AcademicTitle = CleanText(title),
                        StaffRate = staffRate,
                        EmploymentType = employmentType,
                        IsExternal = isExternal,
                        AcademicYear = semester == 1 ? academicYearStart : academicYearStart + 1,
                        Semester = semester,
                        Discipline = CleanDisciplineName(cell1),
                        Group = ExtractGroupCode(cell2.Contains("-") ? cell2 : ""),
                        ActivityType = string.IsNullOrEmpty(activityType) ? "Не указано" : activityType,
                        PlannedHours = hours,
                        ActualHours = 0
                    };

                    items.Add(item);
                    Console.WriteLine($"  ✓ Найдено: {item.Discipline} | {hours}ч");
                }
            }
        }

        // Метод для определения семестра по содержимому таблицы
        private static int DetermineSemesterFromTable(Word.Table table)
        {
            try
            {
                // Ищем указание семестра в первых 5 строках
                for (int row = 1; row <= Math.Min(5, table.Rows.Count); row++)
                {
                    for (int col = 1; col <= Math.Min(3, table.Columns.Count); col++)
                    {
                        string cellText = GetCellText(table, row, col);
                        if (!string.IsNullOrEmpty(cellText))
                        {
                            string lowerText = cellText.ToLower();
                            if (lowerText.Contains("1 сем") || lowerText.Contains("первый семестр"))
                                return 1;
                            if (lowerText.Contains("2 сем") || lowerText.Contains("второй семестр"))
                                return 2;
                        }
                    }
                }
            }
            catch { }

            return 0;
        }

        private static string ExtractTeacherNameFromWord(Word.Document doc, string fileName)
        {
            try
            {
                // Сначала пробуем из имени файла
                string[] nameParts = fileName.Split('_');
                if (nameParts.Length >= 4)
                {
                    string lastName = nameParts.Length > 1 ? nameParts[1] : "";
                    string firstName = nameParts.Length > 2 ? nameParts[2] : "";
                    string middleName = nameParts.Length > 3 ? nameParts[3] : "";

                    string name = $"{lastName} {firstName} {middleName}".Trim();
                    if (!string.IsNullOrEmpty(name) && name.Length > 3)
                        return name;
                }

                // Ищем ФИО в таблице
                foreach (Word.Table table in doc.Tables)
                {
                    if (table.Rows.Count >= 2 && table.Columns.Count >= 2)
                    {
                        // Проверяем разные ячейки
                        for (int r = 1; r <= Math.Min(3, table.Rows.Count); r++)
                        {
                            for (int c = 1; c <= Math.Min(3, table.Columns.Count); c++)
                            {
                                string cellText = GetCellText(table, r, c);
                                if (!string.IsNullOrEmpty(cellText) && cellText.Contains(" "))
                                {
                                    string[] parts = cellText.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                                    if (parts.Length >= 3) // Фамилия Имя Отчество
                                    {
                                        return CleanText(cellText);
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch { }

            return Path.GetFileNameWithoutExtension(fileName);
        }

        private static string ExtractPositionFromWord(Word.Document doc)
        {
            try
            {
                string docText = doc.Content.Text.ToLower();

                // Проверяем конкретные слова с учетом контекста
                if (docText.Contains("профессор") && !docText.Contains("доцент"))
                    return "Профессор";
                if (docText.Contains("доцент") && !docText.Contains("профессор"))
                    return "Доцент";
                if (docText.Contains("старший преподаватель"))
                    return "Старший преподаватель";
                if (docText.Contains("преподаватель"))
                    return "Преподаватель";

                // По умолчанию - профессор для пользователя с докторской степенью
                if (ExtractAcademicDegreeFromWord(doc).Contains("Доктор"))
                    return "Профессор";
            }
            catch { }
            return "Преподаватель";
        }

        private static string ExtractAcademicDegreeFromWord(Word.Document doc)
        {
            try
            {
                string docText = doc.Content.Text.ToLower();

                // Ищем разные варианты написания
                if (docText.Contains("доктор технических наук") || docText.Contains("д.т.н."))
                    return "Доктор технических наук";
                if (docText.Contains("доктор наук") || docText.Contains("д.н."))
                    return "Доктор наук";
                if (docText.Contains("кандидат технических наук") || docText.Contains("к.т.н."))
                    return "Кандидат технических наук";
                if (docText.Contains("кандидат наук") || docText.Contains("к.н."))
                    return "Кандидат наук";

                // Дополнительные варианты
                if (docText.Contains("д.физ-мат") || docText.Contains("д.ф.-м."))
                    return "Доктор физико-математических наук";
                if (docText.Contains("д.экон") || docText.Contains("д.э.н."))
                    return "Доктор экономических наук";
                if (docText.Contains("к.физ-мат") || docText.Contains("к.ф.-м."))
                    return "Кандидат физико-математических наук";
                if (docText.Contains("к.экон") || docText.Contains("к.э.н."))
                    return "Кандидат экономических наук";
            }
            catch { }
            return "";
        }

        private static string ExtractAcademicTitleFromWord(Word.Document doc)
        {
            try
            {
                string docText = doc.Content.Text.ToLower();

                // Ищем звание профессора
                if (docText.Contains("профессор") && (docText.Contains("профессор") || docText.Contains("professor")))
                    return "Профессор";

                // Ищем звание доцента
                if (docText.Contains("доцент") && (docText.Contains("доцент") || docText.Contains("docent")))
                    return "Доцент";

                // Ищем старшего преподавателя
                if (docText.Contains("старший преподаватель"))
                    return "Старший преподаватель";

                // Ищем просто преподавателя
                if (docText.Contains("преподаватель"))
                    return "Преподаватель";
            }
            catch { }
            return "";
        }

        private static decimal ExtractStaffRateFromWord(Word.Document doc)
        {
            try
            {
                string docText = doc.Content.Text;
                Match match = Regex.Match(docText, @"([\d\.,]+)\s*ставки");
                if (match.Success)
                {
                    string rateStr = match.Groups[1].Value.Replace(',', '.');
                    if (decimal.TryParse(rateStr, System.Globalization.NumberStyles.Any,
                        System.Globalization.CultureInfo.InvariantCulture, out decimal rate))
                        return rate;
                }
            }
            catch { }
            return 1.0m;
        }

        private static bool DetermineEmploymentTypeFromWord(Word.Document doc)
        {
            try
            {
                string docText = doc.Content.Text.ToLower();
                return docText.Contains("совместитель") || docText.Contains("внешний");
            }
            catch { }
            return false;
        }

        // Вспомогательный метод для безопасного получения текста ячейки
        private static string GetCellText(Word.Table table, int row, int column)
        {
            try
            {
                if (row >= 1 && row <= table.Rows.Count &&
                    column >= 1 && column <= table.Columns.Count)
                {
                    return CleanText(table.Cell(row, column).Range.Text);
                }
            }
            catch { }
            return "";
        }

        private static string CleanDisciplineName(string text)
        {
            if (string.IsNullOrEmpty(text))
                return text;

            // Убираем форматирование
            text = text.Replace("*", "").Replace("**", "").Trim();

            // Убираем номера в начале
            text = Regex.Replace(text, @"^\d+[\.\)]\s*", "");

            // Убираем лишние пробелы
            text = Regex.Replace(text, @"\s+", " ").Trim();

            return text;
        }

        private static string ExtractGroupCode(string text)
        {
            if (string.IsNullOrEmpty(text))
                return "";

            // Очищаем текст
            text = CleanText(text);

            // Пробуем найти формат группы (например, ТСА-241, ВУЦ-421)
            Match match = Regex.Match(text, @"[А-Я]{2,}-\d+");
            if (match.Success)
                return match.Value;

            // Если не нашли стандартный формат, возвращаем как есть
            return text;
        }

        private static string NormalizeActivityType(string activity)
        {
            if (string.IsNullOrEmpty(activity))
                return "Не указано";

            activity = activity.ToLower().Trim();

            // Обработка сокращений
            if (activity.Contains("лк") || activity.Contains("лек") || activity == "лк." || activity == "лек.")
                return "Лекция";
            if (activity.Contains("лр") || activity.Contains("лаб") || activity == "лр." || activity == "лаб.")
                return "Лабораторная";
            if (activity.Contains("пр") && !activity.Contains("пр.пр") && !activity.Contains("производ"))
                return "Практика";
            if (activity.Contains("пр.пр") || activity.Contains("производ"))
                return "Производственная практика";
            if (activity.Contains("конс") || activity == "конс.")
                return "Консультация";
            if (activity.Contains("зач") || activity == "зач.")
                return "Зачет";
            if (activity.Contains("экз") || activity == "экз.")
                return "Экзамен";
            if (activity.Contains("курс") && activity.Contains("р"))
                return "Курсовая работа";
            if (activity.Contains("вкр") || activity.Contains("диплом"))
                return "Диплом";

            // Возвращаем с заглавной буквы
            if (activity.Length > 0)
            {
                return char.ToUpper(activity[0]) + activity.Substring(1);
            }

            return activity;
        }

        private static string CleanText(string text)
        {
            if (string.IsNullOrEmpty(text))
                return "";

            // Убираем все управляющие символы
            text = Regex.Replace(text, @"[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]", "");

            // Убираем символы конца ячейки Word
            text = text.Replace("\r", " ").Replace("\u0007", "").Replace("\n", " ");

            // Убираем multiple пробелы
            text = Regex.Replace(text, @"\s+", " ").Trim();

            return text;
        }

        // Извлекаем год из имени файла
        private static int ExtractYearFromFileName(string filePath)
        {
            string fileName = Path.GetFileNameWithoutExtension(filePath);

            // Пробуем разные шаблоны
            Match match = Regex.Match(fileName, @"^(\d{4})");
            if (match.Success)
            {
                int year = int.Parse(match.Groups[1].Value);
                return year;
            }

            match = Regex.Match(fileName, @"_(\d{4})_");
            if (match.Success)
            {
                int year = int.Parse(match.Groups[1].Value);
                return year;
            }

            // Если ничего не нашли, используем текущий год минус 1
            return DateTime.Now.Year - 1;
        }

        private static void PrintParsingStatistics(List<WorkloadItem> items)
        {
            Console.WriteLine($"\n=== ИТОГИ ПАРСИНГА ===");
            Console.WriteLine($"Всего записей: {items.Count}");

            if (items.Count > 0)
            {
                int semester1Count = items.Count(i => i.Semester == 1);
                int semester2Count = items.Count(i => i.Semester == 2);
                int semester0Count = items.Count(i => i.Semester == 0);

                Console.WriteLine($"1 семестр: {semester1Count} записей");
                Console.WriteLine($"2 семестр: {semester2Count} записей");
                Console.WriteLine($"Без семестра: {semester0Count} записей");

                // Выводим статистику по годам
                var yearStats = items.GroupBy(i => i.AcademicYear)
                                     .Select(g => new { Year = g.Key, Count = g.Count() })
                                     .OrderBy(y => y.Year);

                Console.WriteLine("\nРаспределение по годам:");
                foreach (var stat in yearStats)
                {
                    Console.WriteLine($"  {stat.Year} год: {stat.Count} записей");
                }
            }
        }

        public static List<WorkloadItem> ParseCsv(string filePath)
        {
            var items = new List<WorkloadItem>();

            if (!File.Exists(filePath))
            {
                MessageBox.Show($"Файл не найден: {filePath}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return items;
            }

            try
            {
                string[] lines = File.ReadAllLines(filePath, Encoding.GetEncoding(1251));

                if (lines.Length == 0)
                {
                    MessageBox.Show("Файл пуст", "Информация",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return items;
                }

                // Определяем разделитель
                char separator = ';';
                if (!lines[0].Contains(";") && lines[0].Contains(","))
                {
                    separator = ',';
                }

                int lineNumber = 0;
                foreach (string line in lines)
                {
                    lineNumber++;
                    string trimmed = line.Trim();

                    if (string.IsNullOrEmpty(trimmed))
                        continue;

                    // Пропускаем заголовок
                    if (trimmed.StartsWith("ФИО") || trimmed.StartsWith("TeacherName") ||
                        trimmed.StartsWith("фамилия") || lineNumber == 1)
                        continue;

                    string[] parts = trimmed.Split(separator);

                    // Минимальное количество полей
                    if (parts.Length < 7)
                    {
                        Console.WriteLine($"Пропущена строка {lineNumber}: недостаточно полей ({parts.Length})");
                        continue;
                    }

                    try
                    {
                        int plannedHours = parts.Length > 11 ? ParseInt(parts[11]) : 0;

                        // Парсим фактические часы
                        int actualHours = 0;
                        if (parts.Length > 12)
                        {
                            actualHours = ParseInt(parts[12]);
                        }

                       

                        var item = new WorkloadItem
                        {
                            TeacherName = CleanText(parts.Length > 0 ? parts[0] : ""),
                            Position = CleanText(parts.Length > 1 ? parts[1] : ""),
                            AcademicDegree = CleanText(parts.Length > 2 ? parts[2] : ""),
                            AcademicTitle = CleanText(parts.Length > 3 ? parts[3] : ""),
                            StaffRate = parts.Length > 4 ? ParseDecimal(parts[4]) : 1.0m,
                            EmploymentType = CleanText(parts.Length > 5 ? parts[5] : "Основной"),
                            AcademicYear = parts.Length > 6 ? ParseInt(parts[6]) : DateTime.Now.Year,
                            Semester = parts.Length > 7 ? ParseInt(parts[7]) : 0,
                            Discipline = CleanText(parts.Length > 8 ? parts[8] : ""),
                            Group = CleanText(parts.Length > 9 ? parts[9] : ""),
                            ActivityType = CleanText(parts.Length > 10 ? parts[10] : ""),
                            PlannedHours = plannedHours,
                            ActualHours = actualHours,
                            IsExternal = parts.Length > 5 && parts[5].ToLower().Contains("совместитель")
                        };

                        items.Add(item);
                        Console.WriteLine($"✓ CSV строка {lineNumber}: {item.TeacherName} - {item.Discipline} ({plannedHours}ч)");
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"❌ Ошибка в строке CSV {lineNumber}: {ex.Message}");
                        continue;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Ошибка чтения CSV файла: {ex.Message}");
                MessageBox.Show($"Ошибка чтения CSV файла:\n{ex.Message}",
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return items;
        }

        public static void ExportToCsv(List<WorkloadItem> items, string filePath)
        {
            try
            {
                using (StreamWriter writer = new StreamWriter(filePath, false, Encoding.GetEncoding(1251)))
                {
                    // Убираем столбцы "Разница" и "Статус" из заголовков
                    writer.WriteLine("ФИО преподавателя;Должность;Ученая степень;Ученое звание;Ставка;Тип занятости;Учебный год;Семестр;Дисциплина;Группа;Вид занятия;Запланировано часов;Фактически часов");

                    foreach (WorkloadItem item in items)
                    {
                        // Убираем HourDifference и CompletionStatus из строк данных
                        writer.WriteLine(string.Format("{0};{1};{2};{3};{4};{5};{6};{7};{8};{9};{10};{11};{12}",
                            item.TeacherName,
                            item.Position,
                            item.AcademicDegree,
                            item.AcademicTitle,
                            item.StaffRate.ToString().Replace(',', '.'),
                            item.EmploymentType,
                            item.AcademicYear,
                            item.Semester,
                            item.Discipline,
                            item.Group,
                            item.ActivityType,
                            item.PlannedHours,
                            item.ActualHours));
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Ошибка экспорта в CSV: " + ex.Message);
            }
        }

        public static List<WorkloadItem> LoadFromFolder(string folderPath)
        {
            var allItems = new List<WorkloadItem>();

            if (!Directory.Exists(folderPath))
            {
                MessageBox.Show($"Папка не найдена: {folderPath}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return allItems;
            }

            int totalFiles = 0;
            int successfulFiles = 0;

            // Word файлы
            string[] wordFiles = Directory.GetFiles(folderPath, "*.doc");
            wordFiles = wordFiles.Concat(Directory.GetFiles(folderPath, "*.docx")).ToArray();

            foreach (string file in wordFiles)
            {
                totalFiles++;
                try
                {
                    Console.WriteLine($"\nОбработка Word файла: {Path.GetFileName(file)}");
                    var items = ParseWordDocument(file);
                    allItems.AddRange(items);
                    successfulFiles++;
                    Console.WriteLine($"✓ Загружено {items.Count} записей из {Path.GetFileName(file)}");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"❌ Ошибка при загрузке {Path.GetFileName(file)}: {ex.Message}");
                }
            }

            // CSV файлы
            foreach (string file in Directory.GetFiles(folderPath, "*.csv"))
            {
                totalFiles++;
                try
                {
                    Console.WriteLine($"\nОбработка CSV файла: {Path.GetFileName(file)}");
                    var items = ParseCsv(file);
                    allItems.AddRange(items);
                    successfulFiles++;
                    Console.WriteLine($"✓ Загружено {items.Count} записей из {Path.GetFileName(file)}");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"❌ Ошибка при загрузке CSV {Path.GetFileName(file)}: {ex.Message}");
                }
            }

            Console.WriteLine($"\n=== ИТОГИ ЗАГРУЗКИ ИЗ ПАПКИ ===");
            Console.WriteLine($"Обработано файлов: {successfulFiles}/{totalFiles}");
            Console.WriteLine($"Всего записей: {allItems.Count}");

            return allItems;
        }

        private static int ParseInt(string text)
        {
            if (string.IsNullOrEmpty(text))
                return 0;

            // Убираем все нецифровые символы
            string digitsOnly = Regex.Replace(text, @"[^\d\-]", "");

            int result;
            if (int.TryParse(digitsOnly, out result))
                return Math.Abs(result);

            return 0;
        }

        private static decimal ParseDecimal(string text)
        {
            if (string.IsNullOrEmpty(text))
                return 0;

            decimal result;
            string cleanText = text.Replace(',', '.');
            if (decimal.TryParse(cleanText, System.Globalization.NumberStyles.Any,
                System.Globalization.CultureInfo.InvariantCulture, out result))
                return result;
            return 0;
        }
    }
}