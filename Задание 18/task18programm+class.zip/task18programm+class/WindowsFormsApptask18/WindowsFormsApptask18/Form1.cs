﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace WindowsFormsApptask18 
{
    public partial class Form1 : Form
    {
        private TextBox txtInput;
        private Button btnCalculate;
        private Button btnClear;
        private ListBox lstResults;

        public Form1()
        {
            InitializeComponents();
        }

        private void InitializeComponents()
        {
            // Настройка формы
            this.Text = "Калькулятор вероятностей";
            this.Size = new Size(500, 400);
            this.StartPosition = FormStartPosition.CenterScreen;

            // Label для подсказки
            Label lblInput = new Label
            {
                Text = "Введите числа (через пробел или запятую):",
                Location = new Point(20, 20),
                AutoSize = true
            };

            // TextBox для ввода
            txtInput = new TextBox
            {
                Location = new Point(20, 50),
                Size = new Size(440, 20),
                Multiline = false
            };

            // Кнопка Рассчитать
            btnCalculate = new Button
            {
                Text = "Рассчитать",
                Location = new Point(20, 85),
                Size = new Size(100, 30)
            };

            // Кнопка Очистить
            btnClear = new Button
            {
                Text = "Очистить",
                Location = new Point(130, 85),
                Size = new Size(100, 30)
            };

            // ListBox для результатов
            lstResults = new ListBox
            {
                Location = new Point(20, 130),
                Size = new Size(440, 200),
                Font = new Font("Consolas", 10)
            };

            // Добавляем все элементы на форму
            this.Controls.AddRange(new Control[] { lblInput, txtInput, btnCalculate, btnClear, lstResults });

            // Привязываем события
            btnCalculate.Click += btnCalculate_Click;
            btnClear.Click += btnClear_Click;
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            try
            {
                List<double> values = ParseInput(txtInput.Text);
                if (values.Count == 0)
                {
                    MessageBox.Show("Введите числа");
                    return;
                }

                lstResults.Items.Clear();
                lstResults.Items.Add($"Математическое ожидание: {MethodMath.ProbabilityCalculator.mathexpectation(values):F2}");
                lstResults.Items.Add($"Дисперсия: {MethodMath.ProbabilityCalculator.variance(values):F2}");
                lstResults.Items.Add($"Среднеквадратическое отклонение: {MethodMath.ProbabilityCalculator.standarddeviation(values):F2}");
                lstResults.Items.Add($"Медиана: {MethodMath.ProbabilityCalculator.median(values):F2}");
                
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private List<double> ParseInput(string input)
        {
            List<double> numbers = new List<double>();
            string[] parts = input.Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries);
            foreach (string part in parts)
            {
                if (double.TryParse(part, out double num))
                    numbers.Add(num);
            }
            return numbers;
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtInput.Clear();
            lstResults.Items.Clear();
        }
    }
}