﻿using System;
using System.Collections.Generic;

namespace MethodMath
{
    public class ProbabilityCalculator
    {
        /// <summary>
        /// Вычисляет математическое ожидание (среднее арифметическое)
        /// </summary>
        public static double mathexpectation(List<double> values)
        {
            if (values == null || values.Count == 0)
                throw new ArgumentException("Список значений не может быть пустым");

            double sum = 0;
            foreach (var value in values)
                sum += value;
            return sum / values.Count;
        }

        /// <summary>
        /// Вычисляет дисперсию
        /// </summary>
        public static double variance(List<double> values)
        {
            double mean = mathexpectation(values);
            double sum = 0;
            foreach (var value in values)
                sum += Math.Pow(value - mean, 2);
            return sum / values.Count;
        }

        /// <summary>
        /// Вычисляет среднеквадратическое отклонение
        /// </summary>
        public static double standarddeviation(List<double> values)
        {
            return Math.Sqrt(variance(values));
        }

        /// <summary>
        /// Вычисляет медиану
        /// </summary>
        public static double median(List<double> values)
        {
            if (values == null || values.Count == 0)
                throw new ArgumentException("Список значений не может быть пустым");

            List<double> sorted = new List<double>(values);
            sorted.Sort();

            int mid = sorted.Count / 2;
            if (sorted.Count % 2 == 0)
                return (sorted[mid - 1] + sorted[mid]) / 2;
            else
                return sorted[mid];
        }
        

    }
}