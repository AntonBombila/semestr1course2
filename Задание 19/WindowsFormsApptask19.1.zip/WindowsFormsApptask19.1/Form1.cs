﻿using System;
using System.IO;
using System.Windows.Forms;
using Word = Microsoft.Office.Interop.Word;
using System.Diagnostics;

namespace WordWork19
{
    public partial class Form1 : Form
    {
        // Конструктор
        public Form1()
        {
            InitializeComponent();

            // Устанавливаем заголовок формы согласно требованиям
            string authorName = "Житный А. Г.";
            string variantNumber = "1";
            string completionDate = DateTime.Now.ToString("dd/MM/yyyy");
            this.Text = $"Задание №19 выполнил: {authorName}; Номер варианта: {variantNumber}; Дата выполнения: {completionDate}";
        }

        // Переменные для хранения текста строк титульника
        public string labWorkLine = "Лабораторная работа № 1";
        public string disciplineLine = "по дисциплине: «Программирование и основы алгоритмизации»";
        public string topicLine = "на тему: «программируемая настройка параметров документов Microsoft Office Word»";
        public string ministryLine = "Министерство транспорта Российской Федерации";
        public string federalLine = "Федеральное государственное автономное образовательное";
        public string institutionLine = "учреждение высшего образования";
        public string universityLine = "«Российский университет транспорта»";
        public string acronymLine = "(ФГАОУ ВО РУТ(МИИТ), РУТ (МИИТ)";
        public string instituteLine = "Институт транспортной техники и систем управления";
        public string departmentLine = "Кафедра «Управление и защита информации»";
        public string performedByLine = "Выполнил: ст. гр. ТУУ-211";
        public string studentNameLine = "Житный А. Г."; // Автоматически подставится из свойств формы
        public string variantLine = "Вариант №1";
        public string dateLine = "";
        public string checkedByLine = ""; // Будет заполнено пользователем
        public string cityYearLine = "Москва - 2025 г.";

        // Динамические поля (будут заполнены из формы)
        private string documentType = "Лабораторная работа";
        private string workType = "Лабораторная работа";
        private string workNumber = "1";
        private string workName = "Программируемая настройка параметров документов Microsoft Office Word";
        private string workTopic = "программируемая настройка параметров документов Microsoft Office Word";
        private string disciplineName = "Программирование и основы алгоритмизации";

        // Настройки абзацных отступов (в пунктах)
        private float[] lineBeforeSpacing = new float[16];
        private float[] lineAfterSpacing = new float[16];

        // Список названий строк для ComboBox
        private string[] lineTitles = new string[16];

        private void Form1_Load(object sender, EventArgs e)
        {
            // Заполняем комбобоксы данными

            // Вид отчетного документа
            cmbDocumentType.Items.Add("отчёт");
            cmbDocumentType.Items.Add("реферат");
            cmbDocumentType.Items.Add("эссе");
            cmbDocumentType.Items.Add("курсовой проект");
            cmbDocumentType.Items.Add("курсовая работа");
            cmbDocumentType.Items.Add("доклад");
            cmbDocumentType.Items.Add("домашнее задание");
            cmbDocumentType.SelectedIndex = 0; // отчёт по умолчанию

            // Вид работы
            cmbWorkType.Items.Add("лабораторная работа");
            cmbWorkType.Items.Add("практическая работа");
            cmbWorkType.Items.Add("индивидуальное задание");
            cmbWorkType.Items.Add("учебная практика");
            cmbDocumentType.Items.Add("производственная практика");
            cmbDocumentType.Items.Add("преддипломная практика");
            cmbWorkType.SelectedIndex = 0; // лабораторная работа по умолчанию

            // Номер работы (1-10)
            for (int i = 1; i <= 10; i++)
            {
                cmbWorkNumber.Items.Add(i.ToString());
            }
            cmbWorkNumber.SelectedIndex = 0; // 1 по умолчанию

            // Наименование работы
            txtWorkName.Text = workName;

            // Тема работы
            txtWorkTopic.Text = workTopic;

            // Наименование дисциплины
            txtDiscipline.Text = disciplineName;

            // Имя проверяющего и должность
            cmbCheckerPosition.Items.Add("ассистент");
            cmbCheckerPosition.Items.Add("доцент");
            cmbCheckerPosition.Items.Add("профессор");
            cmbCheckerPosition.SelectedIndex = 1; // доцент по умолчанию

            // Устанавливаем текущую дату
            dateLine = DateTime.Now.ToString("dd.MM.yyyy");

            // Имя автора
            studentNameLine = "Житный А. Г.";

            // Инициализация массивов отступов
            for (int i = 0; i < 16; i++)
            {
                lineBeforeSpacing[i] = 0f;
                lineAfterSpacing[i] = 12f;
            }

            // Особые отступы для некоторых строк
            lineBeforeSpacing[7] = 36f;  // Лабораторная работа (строка 8)
            lineBeforeSpacing[10] = 36f; // Выполнил (строка 11)
            lineBeforeSpacing[15] = 48f; // Москва - год (строка 16)

            // Заполняем ComboBox строками
            cmbLineSelector.Items.Clear();
            lineTitles[0] = "1. Министерство транспорта";
            lineTitles[1] = "2. Федеральное государственное";
            lineTitles[2] = "3. учреждение высшего образования";
            lineTitles[3] = "4. «Российский университет транспорта»";
            lineTitles[4] = "5. (ФГАОУ ВО РУТ(МИИТ), РУТ (МИИТ)";
            lineTitles[5] = "6. Институт транспортной техники";
            lineTitles[6] = "7. Кафедра «Управление и защита информации»";
            lineTitles[7] = "8. Название работы";
            lineTitles[8] = "9. по дисциплине";
            lineTitles[9] = "10. на тему";
            lineTitles[10] = "11. Выполнил";
            lineTitles[11] = "12. ФИО студента";
            lineTitles[12] = "13. Вариант №1";
            lineTitles[13] = "14. Дата";
            lineTitles[14] = "15. Проверил";
            lineTitles[15] = "16. Москва - год";

            for (int i = 0; i < 16; i++)
            {
                cmbLineSelector.Items.Add(lineTitles[i]);
            }
            cmbLineSelector.SelectedIndex = 0;
        }

        private void cmbLineSelector_SelectedIndexChanged(object sender, EventArgs e)
        {
            int selectedIndex = cmbLineSelector.SelectedIndex;
            if (selectedIndex >= 0 && selectedIndex < 16)
            {
                // Устанавливаем значения в NumericUpDown
                numBeforeSpacing.Value = (decimal)lineBeforeSpacing[selectedIndex];
                numAfterSpacing.Value = (decimal)lineAfterSpacing[selectedIndex];

                // Показываем текст выбранной строки
                UpdateSelectedLineText(selectedIndex);
            }
        }

        // Обновление текста выбранной строки
        private void UpdateSelectedLineText(int index)
        {
            string lineText = "";

            switch (index)
            {
                case 0: lineText = ministryLine; break;
                case 1: lineText = federalLine; break;
                case 2: lineText = institutionLine; break;
                case 3: lineText = universityLine; break;
                case 4: lineText = acronymLine; break;
                case 5: lineText = instituteLine; break;
                case 6: lineText = departmentLine; break;
                case 7: lineText = labWorkLine; break;
                case 8: lineText = disciplineLine; break;
                case 9: lineText = topicLine; break;
                case 10: lineText = performedByLine; break;
                case 11: lineText = studentNameLine; break;
                case 12: lineText = variantLine; break;
                case 13: lineText = dateLine; break;
                case 14: lineText = checkedByLine; break;
                case 15: lineText = cityYearLine; break;
            }

            txtSelectedLine.Text = lineText;
        }

        // Обработчик кнопки "Применить отступы"
        private void btnApplySpacing_Click(object sender, EventArgs e)
        {
            int selectedIndex = cmbLineSelector.SelectedIndex;
            if (selectedIndex >= 0 && selectedIndex < 16)
            {
                lineBeforeSpacing[selectedIndex] = (float)numBeforeSpacing.Value;
                lineAfterSpacing[selectedIndex] = (float)numAfterSpacing.Value;

                MessageBox.Show($"Отступы для строки {selectedIndex + 1} применены:\n" +
                               $"Перед: {lineBeforeSpacing[selectedIndex]} пт\n" +
                               $"После: {lineAfterSpacing[selectedIndex]} пт",
                               "Отступы применены", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void CreateWord_Click(object sender, EventArgs e)
        {
            // Получаем данные из формы
            documentType = cmbDocumentType.SelectedItem?.ToString() ?? "отчёт";
            workType = cmbWorkType.SelectedItem?.ToString() ?? "лабораторная работа";
            workNumber = cmbWorkNumber.SelectedItem?.ToString() ?? "1";
            workName = txtWorkName.Text;
            workTopic = txtWorkTopic.Text;
            disciplineName = txtDiscipline.Text;

            // Формируем проверяющего
            string checkerName = txtCheckerName.Text;
            string checkerPosition = cmbCheckerPosition.SelectedItem?.ToString() ?? "доцент";
            checkedByLine = $"Проверил: {checkerPosition} {checkerName}";

            // Обновляем строки титульника
            labWorkLine = $"{workType} № {workNumber}";
            disciplineLine = $"по дисциплине: «{disciplineName}»";
            topicLine = $"на тему: «{workTopic}»";
            studentNameLine = GetAuthorNameFromFormTitle();

            Word.Application oWord = null;
            Word.Document oDoc = null;

            try
            {
                oWord = new Word.Application();
                oWord.Visible = false;
                oDoc = oWord.Documents.Add();

                // Устанавливаем шрифт Times New Roman для всего документа
                oDoc.Content.Font.Name = "Times New Roman";
                oDoc.Content.Font.Size = 14;

                // 1. Министерство транспорта Российской Федерации - по центру
                Word.Paragraph line1 = oDoc.Paragraphs.Add();
                line1.Range.Font.Size = 14;
                line1.Range.Text = ministryLine;
                line1.Alignment = Word.WdParagraphAlignment.wdAlignParagraphCenter;
                // Настройка абзацных отступов 
                line1.Format.SpaceBefore = lineBeforeSpacing[0];
                line1.Format.SpaceAfter = lineAfterSpacing[0];
                line1.Range.InsertParagraphAfter();

                // 2. Федеральное государственное автономное образовательное - по центру
                Word.Paragraph line2 = oDoc.Paragraphs.Add();
                line2.Range.Font.Size = 14;
                line2.Range.Text = federalLine;
                line2.Alignment = Word.WdParagraphAlignment.wdAlignParagraphCenter;
                line2.Format.SpaceBefore = lineBeforeSpacing[1];
                line2.Format.SpaceAfter = lineAfterSpacing[1];
                line2.Range.InsertParagraphAfter();

                // 3. учреждение высшего образования - по центру
                Word.Paragraph line3 = oDoc.Paragraphs.Add();
                line3.Range.Font.Size = 14;
                line3.Range.Text = institutionLine;
                line3.Alignment = Word.WdParagraphAlignment.wdAlignParagraphCenter;
                line3.Format.SpaceBefore = lineBeforeSpacing[2];
                line3.Format.SpaceAfter = lineAfterSpacing[2];
                line3.Range.InsertParagraphAfter();

                // 4. «Российский университет транспорта» - по центру
                Word.Paragraph line4 = oDoc.Paragraphs.Add();
                line4.Range.Font.Size = 14;
                line4.Range.Text = universityLine;
                line4.Alignment = Word.WdParagraphAlignment.wdAlignParagraphCenter;
                line4.Format.SpaceBefore = lineBeforeSpacing[3];
                line4.Format.SpaceAfter = lineAfterSpacing[3];
                line4.Range.InsertParagraphAfter();

                // 5. (ФГАОУ ВО РУТ(МИИТ), РУТ (МИИТ) - по центру с подчеркиванием
                object missing = System.Reflection.Missing.Value;
                object autoFitBehavior = Microsoft.Office.Interop.Word.WdAutoFitBehavior.wdAutoFitWindow;

                Word.Table underlineTable = oDoc.Tables.Add(
                    oDoc.Paragraphs.Add().Range,
                    1,
                    1,
                    ref missing,
                    ref missing);

                underlineTable.Cell(1, 1).Range.Text = acronymLine;
                underlineTable.Cell(1, 1).Range.Font.Size = 14;
                underlineTable.Cell(1, 1).Range.ParagraphFormat.Alignment =
                    Microsoft.Office.Interop.Word.WdParagraphAlignment.wdAlignParagraphCenter;

                underlineTable.Borders.Enable = 0;

                Word.Border bottomBorder = underlineTable.Borders[(Microsoft.Office.Interop.Word.WdBorderType)Microsoft.Office.Interop.Word.WdBorderType.wdBorderBottom];
                bottomBorder.LineStyle = Microsoft.Office.Interop.Word.WdLineStyle.wdLineStyleSingle;
                bottomBorder.LineWidth = Microsoft.Office.Interop.Word.WdLineWidth.wdLineWidth050pt;
                bottomBorder.Color = Microsoft.Office.Interop.Word.WdColor.wdColorBlack;

                underlineTable.Borders[(Microsoft.Office.Interop.Word.WdBorderType)Microsoft.Office.Interop.Word.WdBorderType.wdBorderTop].LineStyle =
                    Microsoft.Office.Interop.Word.WdLineStyle.wdLineStyleNone;
                underlineTable.Borders[(Microsoft.Office.Interop.Word.WdBorderType)Microsoft.Office.Interop.Word.WdBorderType.wdBorderLeft].LineStyle =
                    Microsoft.Office.Interop.Word.WdLineStyle.wdLineStyleNone;
                underlineTable.Borders[(Microsoft.Office.Interop.Word.WdBorderType)Microsoft.Office.Interop.Word.WdBorderType.wdBorderRight].LineStyle =
                    Microsoft.Office.Interop.Word.WdLineStyle.wdLineStyleNone;

                underlineTable.LeftPadding = 0;
                underlineTable.RightPadding = 0;
                underlineTable.TopPadding = 0;
                underlineTable.BottomPadding = 0;

                underlineTable.AutoFitBehavior((Microsoft.Office.Interop.Word.WdAutoFitBehavior)autoFitBehavior);

                // Настройка отступов для таблицы
                underlineTable.Range.ParagraphFormat.SpaceBefore = lineBeforeSpacing[4];
                underlineTable.Range.ParagraphFormat.SpaceAfter = lineAfterSpacing[4];

                // 6. Институт транспортной техники и систем управления - по центру
                Word.Paragraph line6 = oDoc.Paragraphs.Add();
                line6.Range.Font.Size = 14;
                line6.Range.Text = instituteLine;
                line6.Alignment = Microsoft.Office.Interop.Word.WdParagraphAlignment.wdAlignParagraphCenter;
                line6.Format.SpaceBefore = lineBeforeSpacing[5];
                line6.Format.SpaceAfter = lineAfterSpacing[5];
                line6.Range.InsertParagraphAfter();

                // 7. Кафедра «Управление и защита информации» - по центру
                Word.Paragraph line7 = oDoc.Paragraphs.Add();
                line7.Range.Font.Size = 14;
                line7.Range.Text = departmentLine;
                line7.Alignment = Word.WdParagraphAlignment.wdAlignParagraphCenter;
                line7.Format.SpaceBefore = lineBeforeSpacing[6];
                line7.Format.SpaceAfter = lineAfterSpacing[6];
                line7.Range.InsertParagraphAfter();

                // 8. Вид работы (например, Лабораторная работа № 1) - по центру
                Word.Paragraph line8 = oDoc.Paragraphs.Add();
                line8.Range.Font.Size = 28;
                line8.Range.Text = labWorkLine;
                line8.Alignment = Word.WdParagraphAlignment.wdAlignParagraphCenter;
                line8.Format.SpaceBefore = lineBeforeSpacing[7];
                line8.Format.SpaceAfter = lineAfterSpacing[7];
                line8.Range.InsertParagraphAfter();

                // 9. по дисциплине: «Программирование и основы алгоритмизации» - по центру
                Word.Paragraph line9 = oDoc.Paragraphs.Add();
                line9.Range.Font.Size = 14;
                line9.Range.Text = disciplineLine;
                line9.Alignment = Word.WdParagraphAlignment.wdAlignParagraphCenter;
                line9.Format.SpaceBefore = lineBeforeSpacing[8];
                line9.Format.SpaceAfter = lineAfterSpacing[8];
                line9.Range.InsertParagraphAfter();

                // 10. на тему: «программируемая настройка параметров документов Microsoft Office Word» - по центру
                Word.Paragraph line10 = oDoc.Paragraphs.Add();
                line10.Range.Font.Size = 14;
                line10.Range.Text = topicLine;
                line10.Alignment = Word.WdParagraphAlignment.wdAlignParagraphCenter;
                line10.Format.SpaceBefore = lineBeforeSpacing[9];
                line10.Format.SpaceAfter = lineAfterSpacing[9];
                line10.Range.InsertParagraphAfter();

                // 11. Выполнил: ст. гр. ТУУ-211 - выравнивание вправо
                Word.Paragraph line11 = oDoc.Paragraphs.Add();
                line11.Range.Font.Size = 14;
                line11.Range.Text = performedByLine;
                line11.Alignment = Word.WdParagraphAlignment.wdAlignParagraphRight;
                line11.Format.SpaceBefore = lineBeforeSpacing[10];
                line11.Format.SpaceAfter = lineAfterSpacing[10];
                line11.Range.InsertParagraphAfter();

                // 12. Имя автора - выравнивание вправо
                Word.Paragraph line12 = oDoc.Paragraphs.Add();
                line12.Range.Font.Size = 14;
                line12.Range.Text = studentNameLine;
                line12.Alignment = Word.WdParagraphAlignment.wdAlignParagraphRight;
                line12.Format.SpaceBefore = lineBeforeSpacing[11];
                line12.Format.SpaceAfter = lineAfterSpacing[11];
                line12.Range.InsertParagraphAfter();

                // 13. Вариант №1 - выравнивание вправо
                Word.Paragraph line13 = oDoc.Paragraphs.Add();
                line13.Range.Font.Size = 14;
                line13.Range.Text = variantLine;
                line13.Alignment = Word.WdParagraphAlignment.wdAlignParagraphRight;
                line13.Format.SpaceBefore = lineBeforeSpacing[12];
                line13.Format.SpaceAfter = lineAfterSpacing[12];
                line13.Range.InsertParagraphAfter();

                // 14. Дата - выравнивание вправо
                Word.Paragraph line14 = oDoc.Paragraphs.Add();
                line14.Range.Font.Size = 14;
                line14.Range.Text = dateLine;
                line14.Alignment = Word.WdParagraphAlignment.wdAlignParagraphRight;
                line14.Format.SpaceBefore = lineBeforeSpacing[13];
                line14.Format.SpaceAfter = lineAfterSpacing[13];
                line14.Range.InsertParagraphAfter();

                // Надстрочная надпись "(дата выполнения)"
                Word.Paragraph dateExecutionSuperscript = oDoc.Paragraphs.Add();
                dateExecutionSuperscript.Range.Font.Size = 12;
                dateExecutionSuperscript.Range.Font.Superscript = 1;
                dateExecutionSuperscript.Range.Text = "(дата выполнения)";
                dateExecutionSuperscript.Alignment = Word.WdParagraphAlignment.wdAlignParagraphRight;
                dateExecutionSuperscript.Format.SpaceBefore = lineBeforeSpacing[13];
                dateExecutionSuperscript.Format.SpaceAfter = lineAfterSpacing[13];
                dateExecutionSuperscript.Range.InsertParagraphAfter();

                // 15. Проверил: должность и имя - выравнивание вправо
                Word.Paragraph line15 = oDoc.Paragraphs.Add();
                line15.Range.Font.Size = 14;
                line15.Range.Text = checkedByLine;
                line15.Alignment = Word.WdParagraphAlignment.wdAlignParagraphRight;
                line15.Format.SpaceBefore = lineBeforeSpacing[14];
                line15.Format.SpaceAfter = lineAfterSpacing[14];
                line15.Range.InsertParagraphAfter();

                // Надстрочная надпись "(дата приёмки)"
                Word.Paragraph dateAcceptanceSuperscript = oDoc.Paragraphs.Add();
                dateAcceptanceSuperscript.Range.Font.Size = 12;
                dateAcceptanceSuperscript.Range.Font.Superscript = 1;
                dateAcceptanceSuperscript.Range.Text = "(дата приёмки)";
                dateAcceptanceSuperscript.Alignment = Word.WdParagraphAlignment.wdAlignParagraphRight;
                dateAcceptanceSuperscript.Format.SpaceBefore = lineBeforeSpacing[14];
                dateAcceptanceSuperscript.Format.SpaceAfter = lineAfterSpacing[14];
                dateAcceptanceSuperscript.Range.InsertParagraphAfter();

                // 16. Москва - 2025 г. - по центру
                Word.Paragraph line16 = oDoc.Paragraphs.Add();
                line16.Range.Font.Size = 14;
                line16.Range.Text = cityYearLine;
                line16.Alignment = Word.WdParagraphAlignment.wdAlignParagraphCenter;
                line16.Format.SpaceBefore = lineBeforeSpacing[15];
                line16.Format.SpaceAfter = lineAfterSpacing[15];
                line16.Range.InsertParagraphAfter();

                // Сохраняем документ с уникальным именем
                string timestamp = DateTime.Now.ToString("yyyyMMdd_HHmmss");
                string fileName = $"Титульный_лист_Вариант1_{timestamp}.docx";
                string filePath = Path.Combine(System.Windows.Forms.Application.StartupPath, fileName);

                if (File.Exists(filePath))
                {
                    File.Delete(filePath);
                }

                oDoc.SaveAs(filePath, Word.WdSaveFormat.wdFormatDocumentDefault);

                // Закрываем документ и Word
                oDoc.Close(false);
                oWord.Quit();

                // открываем созданный файл
                OpenWordDocument(filePath);

            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при создании документа: {ex.Message}",
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);

                try
                {
                    if (oWord != null)
                    {
                        oWord.Quit();
                    }
                }
                catch { }
            }
            finally
            {
                // Освобождаем ресурсы
                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();
            }
        }

        // Метод для извлечения имени автора из заголовка формы
        private string GetAuthorNameFromFormTitle()
        {
            string title = this.Text;
            try
            {
                // Ищем "выполнил: " в заголовке
                int startIndex = title.IndexOf("выполнил:", StringComparison.OrdinalIgnoreCase);
                if (startIndex >= 0)
                {
                    startIndex += "выполнил:".Length;
                    int endIndex = title.IndexOf(";", startIndex);
                    if (endIndex > startIndex)
                    {
                        return title.Substring(startIndex, endIndex - startIndex).Trim();
                    }
                }
            }
            catch
            {
                // В случае ошибки возвращаем значение по умолчанию
            }
            return "Житный А. Г.";
        }

        // Метод для открытия Word документа
        private void OpenWordDocument(string filePath)
        {
            try
            {
                if (File.Exists(filePath))
                {
                    // Открываем файл в Word
                    Process.Start(filePath);

                    MessageBox.Show($"Документ создан и открыт: {filePath}",
                        "Готово", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("Созданный файл не найден.",
                        "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при открытии файла: {ex.Message}",
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void CreateReceipt_Click(object sender, EventArgs e)
        {
            CreateDeclarationDocument();
        }

        // Метод для создания заявления (второй документ)
        private void CreateDeclarationDocument()
        {
            Word.Application oWord = null;
            Word.Document oDoc = null;

            try
            {
                oWord = new Word.Application();
                oWord.Visible = false;
                oDoc = oWord.Documents.Add();

                // Устанавливаем шрифт Times New Roman 10pt
                oDoc.Content.Font.Name = "Times New Roman";
                oDoc.Content.Font.Size = 10;

                // Устанавливаем альбомную ориентацию
                oDoc.PageSetup.Orientation = Word.WdOrientation.wdOrientPortrait;

                // Устанавливаем поля страницы как в XML (в twips)
                // 1 twip = 1/1440 дюйма, но Word работает с точками
                // Преобразуем: 239 twips = 239/20 = 11.95 pt ≈ 0.42 см
                oDoc.PageSetup.TopMargin = 11.95f;    // 239 twips
                oDoc.PageSetup.BottomMargin = 11.95f; // 239 twips
                oDoc.PageSetup.LeftMargin = 22.6f;    // 452 twips
                oDoc.PageSetup.RightMargin = 25.05f;  // 501 twips

                // === ШАПКА ЗАЯВЛЕНИЯ (всё по правому краю) ===

                // 1. "Генеральному директору"
                Word.Paragraph p1 = oDoc.Content.Paragraphs.Add();
                p1.Range.Text = "Генеральному директору";
                p1.Alignment = Word.WdParagraphAlignment.wdAlignParagraphRight;
                p1.Format.SpaceAfter = 0;
                p1.Range.InsertParagraphAfter();

                // 2. Подчеркнутая строка (22 подчеркивания)
                Word.Paragraph p2 = oDoc.Content.Paragraphs.Add();
                p2.Range.Text = "______________________";
                p2.Alignment = Word.WdParagraphAlignment.wdAlignParagraphRight;
                p2.Format.SpaceAfter = 0;
                p2.Range.InsertParagraphAfter();

                // 3. Вторая подчеркнутая строка
                Word.Paragraph p3 = oDoc.Content.Paragraphs.Add();
                p3.Range.Text = "______________________";
                p3.Alignment = Word.WdParagraphAlignment.wdAlignParagraphRight;
                p3.Format.SpaceAfter = 0;
                p3.Range.InsertParagraphAfter();

                // 4. "от" (по буквам как в XML: о т)
                Word.Paragraph p4 = oDoc.Content.Paragraphs.Add();
                p4.Range.Text = "от";
                p4.Alignment = Word.WdParagraphAlignment.wdAlignParagraphRight;
                p4.Format.SpaceAfter = 0;
                p4.Range.InsertParagraphAfter();

                // 5. Подчеркнутая строка для ФИО
                Word.Paragraph p5 = oDoc.Content.Paragraphs.Add();
                p5.Range.Text = "______________________";
                p5.Alignment = Word.WdParagraphAlignment.wdAlignParagraphRight;
                p5.Format.SpaceAfter = 0;
                p5.Range.InsertParagraphAfter();

                // 6. Подчеркнутая строка для должности
                Word.Paragraph p6 = oDoc.Content.Paragraphs.Add();
                p6.Range.Text = "______________________";
                p6.Alignment = Word.WdParagraphAlignment.wdAlignParagraphRight;
                p6.Format.SpaceAfter = 0;
                p6.Range.InsertParagraphAfter();

                // 7. Подчеркнутая строка для отдела
                Word.Paragraph p7 = oDoc.Content.Paragraphs.Add();
                p7.Range.Text = "______________________";
                p7.Alignment = Word.WdParagraphAlignment.wdAlignParagraphRight;
                p7.Format.SpaceAfter = 6; // 120 twips = 6 pt
                p7.Range.InsertParagraphAfter();

                // Пустая строка (как в XML)
                Word.Paragraph p8 = oDoc.Content.Paragraphs.Add();
                p8.Range.Text = "";
                p8.Format.SpaceAfter = 0;
                p8.Range.InsertParagraphAfter();

                // === ТЕКСТ ЗАЯВЛЕНИЯ ===

                // 9. "ЗАЯВЛЕНИЕ" - по центру, жирный
                Word.Paragraph p9 = oDoc.Content.Paragraphs.Add();
                p9.Range.Text = "ЗАЯВЛЕНИЕ";
                p9.Range.Font.Bold = 1;
                p9.Alignment = Word.WdParagraphAlignment.wdAlignParagraphCenter;
                p9.Format.SpaceAfter = 0;
                p9.Range.InsertParagraphAfter();

                // 10. Весь текст заявления ОДНОЙ строкой (как в XML)
                Word.Paragraph p10 = oDoc.Content.Paragraphs.Add();
                p10.Range.Text = "Прошу предоставить мне отпуск по беременности и родам с «__ _»__________2020 г. на __________ календарных дней.";
                p10.Range.Font.Bold = 0;
                p10.Alignment = Word.WdParagraphAlignment.wdAlignParagraphLeft;
                p10.Format.SpaceAfter = 0;
                p10.Format.Alignment = Word.WdParagraphAlignment.wdAlignParagraphJustify; // по ширине
                p10.Range.InsertParagraphAfter();

                // 11. "Приложение:" с отступом сверху 18 pt
                Word.Paragraph p11 = oDoc.Content.Paragraphs.Add();
                p11.Range.Text = "Приложение:";
                p11.Range.Font.Bold = 0;
                p11.Alignment = Word.WdParagraphAlignment.wdAlignParagraphLeft;
                p11.Format.SpaceBefore = 18; // 360 twips = 18 pt
                p11.Format.SpaceAfter = 0;
                p11.Range.InsertParagraphAfter();

                // 12. Лист нетрудоспособности
                Word.Paragraph p12 = oDoc.Content.Paragraphs.Add();
                p12.Range.Text = "Лист нетрудоспособности бланк серия _________ от _________ г.";
                p12.Range.Font.Bold = 0;
                p12.Alignment = Word.WdParagraphAlignment.wdAlignParagraphLeft;
                p12.Format.SpaceBefore = 6;  // 120 twips = 6 pt
                p12.Format.SpaceAfter = 24; // 480 twips = 24 pt
                p12.Range.InsertParagraphAfter();

                // 13. Дата - выравнивание по правому краю
                Word.Paragraph p13 = oDoc.Content.Paragraphs.Add();
                p13.Range.Text = "«____» _________2020 г.";
                p13.Range.Font.Bold = 0;
                p13.Alignment = Word.WdParagraphAlignment.wdAlignParagraphRight;
                p13.Format.SpaceAfter = 0;
                p13.Range.InsertParagraphAfter();

                // 14. Подпись - выравнивание по правому краю с табуляцией
                Word.Paragraph p14 = oDoc.Content.Paragraphs.Add();
                // Добавляем табуляцию для отступа
                p14.Range.Text = "\t_____________подпись";
                p14.Range.Font.Bold = 0;
                p14.Alignment = Word.WdParagraphAlignment.wdAlignParagraphRight;
                p14.Format.SpaceAfter = 24; // 480 twips = 24 pt
                p14.Range.InsertParagraphAfter();

                // 15. "СОГЛАСОВАНО:"
                Word.Paragraph p15 = oDoc.Content.Paragraphs.Add();
                p15.Range.Text = "СОГЛАСОВАНО:";
                p15.Range.Font.Bold = 0;
                p15.Alignment = Word.WdParagraphAlignment.wdAlignParagraphLeft;
                p15.Format.SpaceAfter = 0;
                p15.Range.InsertParagraphAfter();

                // 16. "Непосредственный руководитель:"
                Word.Paragraph p16 = oDoc.Content.Paragraphs.Add();
                p16.Range.Text = "Непосредственный руководитель:";
                p16.Range.Font.Bold = 0;
                p16.Alignment = Word.WdParagraphAlignment.wdAlignParagraphLeft;
                p16.Format.SpaceAfter = 0;
                p16.Range.InsertParagraphAfter();

                // 17. Строка с тремя подчеркиваниями и текстом
                Word.Paragraph p17 = oDoc.Content.Paragraphs.Add();
                p17.Range.Text = "_____________________ __________________ __________________    Должность подпись /ФИО/";
                p17.Range.Font.Bold = 0;
                p17.Alignment = Word.WdParagraphAlignment.wdAlignParagraphLeft;
                p17.Format.SpaceAfter = 27; // 540 twips = 27 pt
                p17.Range.InsertParagraphAfter();

                // 18. "Сотрудник службы кадров:" с табуляциями
                Word.Paragraph p18 = oDoc.Content.Paragraphs.Add();
                p18.Range.Text = "Сотрудник службы кадров:";
                p18.Range.Font.Bold = 0;
                p18.Alignment = Word.WdParagraphAlignment.wdAlignParagraphLeft;
                p18.Format.SpaceAfter = 0;
                p18.Range.InsertParagraphAfter();

                // 19. Строка с тремя подчеркиваниями и "Подпись /ФИО/" (как в оригинальном файле)
                Word.Paragraph p19 = oDoc.Content.Paragraphs.Add();
                p19.Range.Text = "_____________________ __________________ __________________     Подпись /ФИО/";
                p19.Range.Font.Bold = 0;
                p19.Alignment = Word.WdParagraphAlignment.wdAlignParagraphLeft;
                p19.Format.SpaceAfter = 0;
                p19.Range.InsertParagraphAfter();

                // Сохраняем документ
                string fileName = "Заявление_отпуск_по_беременности.docx";
                string filePath = Path.Combine(System.Windows.Forms.Application.StartupPath, fileName);

                if (File.Exists(filePath))
                {
                    File.Delete(filePath);
                }

                oDoc.SaveAs(filePath, Word.WdSaveFormat.wdFormatDocumentDefault);

                // Закрываем
                oDoc.Close(false);
                oWord.Quit();

                OpenWordDocument(filePath);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при создании заявления: {ex.Message}",
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);

                try
                {
                    if (oWord != null) oWord.Quit();
                }
                catch { }
            }
            finally
            {
                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();
            }
        }



    }
}