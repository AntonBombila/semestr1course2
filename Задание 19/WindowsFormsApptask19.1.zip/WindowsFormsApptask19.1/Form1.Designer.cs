﻿namespace WordWork19
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.CreateWord = new System.Windows.Forms.Button();
            this.CreateReceipt = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.txtCheckerName = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.cmbCheckerPosition = new System.Windows.Forms.ComboBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.txtSelectedLine = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.btnApplySpacing = new System.Windows.Forms.Button();
            this.numAfterSpacing = new System.Windows.Forms.NumericUpDown();
            this.label11 = new System.Windows.Forms.Label();
            this.numBeforeSpacing = new System.Windows.Forms.NumericUpDown();
            this.label10 = new System.Windows.Forms.Label();
            this.cmbLineSelector = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtDiscipline = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtWorkTopic = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtWorkName = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.cmbWorkNumber = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cmbWorkType = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cmbDocumentType = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numAfterSpacing)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numBeforeSpacing)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // CreateWord
            // 
            this.CreateWord.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.CreateWord.Location = new System.Drawing.Point(1272, 577);
            this.CreateWord.Margin = new System.Windows.Forms.Padding(6);
            this.CreateWord.Name = "CreateWord";
            this.CreateWord.Size = new System.Drawing.Size(316, 96);
            this.CreateWord.TabIndex = 0;
            this.CreateWord.Text = "Создать титульный лист";
            this.CreateWord.UseVisualStyleBackColor = true;
            this.CreateWord.Click += new System.EventHandler(this.CreateWord_Click);
            // 
            // CreateReceipt
            // 
            this.CreateReceipt.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.CreateReceipt.Location = new System.Drawing.Point(1272, 712);
            this.CreateReceipt.Margin = new System.Windows.Forms.Padding(6);
            this.CreateReceipt.Name = "CreateReceipt";
            this.CreateReceipt.Size = new System.Drawing.Size(316, 96);
            this.CreateReceipt.TabIndex = 1;
            this.CreateReceipt.Text = "Создать заявление";
            this.CreateReceipt.UseVisualStyleBackColor = true;
            this.CreateReceipt.Click += new System.EventHandler(this.CreateReceipt_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label7.Location = new System.Drawing.Point(40, 58);
            this.label7.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(266, 29);
            this.label7.TabIndex = 14;
            this.label7.Text = "Проверяющий (ФИО):";
            // 
            // txtCheckerName
            // 
            this.txtCheckerName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.txtCheckerName.Location = new System.Drawing.Point(320, 52);
            this.txtCheckerName.Margin = new System.Windows.Forms.Padding(6);
            this.txtCheckerName.Name = "txtCheckerName";
            this.txtCheckerName.Size = new System.Drawing.Size(496, 35);
            this.txtCheckerName.TabIndex = 15;
            this.txtCheckerName.Text = "Сафронов А.И.";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label8.Location = new System.Drawing.Point(40, 135);
            this.label8.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(148, 29);
            this.label8.TabIndex = 16;
            this.label8.Text = "Должность:";
            // 
            // cmbCheckerPosition
            // 
            this.cmbCheckerPosition.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCheckerPosition.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.cmbCheckerPosition.FormattingEnabled = true;
            this.cmbCheckerPosition.Location = new System.Drawing.Point(320, 129);
            this.cmbCheckerPosition.Margin = new System.Windows.Forms.Padding(6);
            this.cmbCheckerPosition.Name = "cmbCheckerPosition";
            this.cmbCheckerPosition.Size = new System.Drawing.Size(496, 37);
            this.cmbCheckerPosition.TabIndex = 17;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.txtCheckerName);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.cmbCheckerPosition);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox2.Location = new System.Drawing.Point(60, 577);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(6);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(6);
            this.groupBox2.Size = new System.Drawing.Size(1200, 231);
            this.groupBox2.TabIndex = 19;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Проверяющий";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.txtSelectedLine);
            this.groupBox3.Controls.Add(this.label12);
            this.groupBox3.Controls.Add(this.btnApplySpacing);
            this.groupBox3.Controls.Add(this.numAfterSpacing);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Controls.Add(this.numBeforeSpacing);
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Controls.Add(this.cmbLineSelector);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox3.Location = new System.Drawing.Point(1284, 38);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(531, 489);
            this.groupBox3.TabIndex = 20;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Настройка отступов для строк";
            // 
            // txtSelectedLine
            // 
            this.txtSelectedLine.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.txtSelectedLine.Location = new System.Drawing.Point(22, 188);
            this.txtSelectedLine.Multiline = true;
            this.txtSelectedLine.Name = "txtSelectedLine";
            this.txtSelectedLine.ReadOnly = true;
            this.txtSelectedLine.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtSelectedLine.Size = new System.Drawing.Size(410, 60);
            this.txtSelectedLine.TabIndex = 8;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label12.Location = new System.Drawing.Point(17, 156);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(233, 29);
            this.label12.TabIndex = 7;
            this.label12.Text = "Выбранная строка:";
            // 
            // btnApplySpacing
            // 
            this.btnApplySpacing.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnApplySpacing.Location = new System.Drawing.Point(324, 407);
            this.btnApplySpacing.Name = "btnApplySpacing";
            this.btnApplySpacing.Size = new System.Drawing.Size(201, 47);
            this.btnApplySpacing.TabIndex = 6;
            this.btnApplySpacing.Text = "Применить отступы";
            this.btnApplySpacing.UseVisualStyleBackColor = true;
            this.btnApplySpacing.Click += new System.EventHandler(this.btnApplySpacing_Click);
            // 
            // numAfterSpacing
            // 
            this.numAfterSpacing.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.numAfterSpacing.Location = new System.Drawing.Point(418, 313);
            this.numAfterSpacing.Name = "numAfterSpacing";
            this.numAfterSpacing.Size = new System.Drawing.Size(80, 35);
            this.numAfterSpacing.TabIndex = 5;
            this.numAfterSpacing.Value = new decimal(new int[] {
            12,
            0,
            0,
            0});
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label11.Location = new System.Drawing.Point(187, 315);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(225, 29);
            this.label11.TabIndex = 4;
            this.label11.Text = "Отступ после (пт):";
            // 
            // numBeforeSpacing
            // 
            this.numBeforeSpacing.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.numBeforeSpacing.Location = new System.Drawing.Point(101, 313);
            this.numBeforeSpacing.Name = "numBeforeSpacing";
            this.numBeforeSpacing.Size = new System.Drawing.Size(80, 35);
            this.numBeforeSpacing.TabIndex = 3;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label10.Location = new System.Drawing.Point(6, 315);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(92, 29);
            this.label10.TabIndex = 2;
            this.label10.Text = "Перед:";
            // 
            // cmbLineSelector
            // 
            this.cmbLineSelector.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbLineSelector.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.cmbLineSelector.FormattingEnabled = true;
            this.cmbLineSelector.Location = new System.Drawing.Point(22, 78);
            this.cmbLineSelector.Name = "cmbLineSelector";
            this.cmbLineSelector.Size = new System.Drawing.Size(280, 37);
            this.cmbLineSelector.TabIndex = 1;
            this.cmbLineSelector.SelectedIndexChanged += new System.EventHandler(this.cmbLineSelector_SelectedIndexChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label9.Location = new System.Drawing.Point(17, 33);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(285, 29);
            this.label9.TabIndex = 0;
            this.label9.Text = "Выберите строку (1-16):";
            // 
            // txtDiscipline
            // 
            this.txtDiscipline.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.txtDiscipline.Location = new System.Drawing.Point(399, 437);
            this.txtDiscipline.Margin = new System.Windows.Forms.Padding(6);
            this.txtDiscipline.Name = "txtDiscipline";
            this.txtDiscipline.Size = new System.Drawing.Size(796, 35);
            this.txtDiscipline.TabIndex = 13;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.Location = new System.Drawing.Point(40, 442);
            this.label6.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(349, 29);
            this.label6.TabIndex = 12;
            this.label6.Text = "Наименование дисциплины:";
            // 
            // txtWorkTopic
            // 
            this.txtWorkTopic.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.txtWorkTopic.Location = new System.Drawing.Point(399, 360);
            this.txtWorkTopic.Margin = new System.Windows.Forms.Padding(6);
            this.txtWorkTopic.Name = "txtWorkTopic";
            this.txtWorkTopic.Size = new System.Drawing.Size(796, 35);
            this.txtWorkTopic.TabIndex = 11;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(40, 365);
            this.label5.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(80, 29);
            this.label5.TabIndex = 10;
            this.label5.Text = "Тема:";
            // 
            // txtWorkName
            // 
            this.txtWorkName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.txtWorkName.Location = new System.Drawing.Point(399, 283);
            this.txtWorkName.Margin = new System.Windows.Forms.Padding(6);
            this.txtWorkName.Name = "txtWorkName";
            this.txtWorkName.Size = new System.Drawing.Size(796, 35);
            this.txtWorkName.TabIndex = 9;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(40, 288);
            this.label4.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(285, 29);
            this.label4.TabIndex = 8;
            this.label4.Text = "Наименование работы:";
            // 
            // cmbWorkNumber
            // 
            this.cmbWorkNumber.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbWorkNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.cmbWorkNumber.FormattingEnabled = true;
            this.cmbWorkNumber.Location = new System.Drawing.Point(399, 206);
            this.cmbWorkNumber.Margin = new System.Windows.Forms.Padding(6);
            this.cmbWorkNumber.Name = "cmbWorkNumber";
            this.cmbWorkNumber.Size = new System.Drawing.Size(196, 37);
            this.cmbWorkNumber.TabIndex = 7;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(40, 212);
            this.label3.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(186, 29);
            this.label3.TabIndex = 6;
            this.label3.Text = "Номер работы:";
            // 
            // cmbWorkType
            // 
            this.cmbWorkType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbWorkType.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.cmbWorkType.FormattingEnabled = true;
            this.cmbWorkType.Location = new System.Drawing.Point(399, 129);
            this.cmbWorkType.Margin = new System.Windows.Forms.Padding(6);
            this.cmbWorkType.Name = "cmbWorkType";
            this.cmbWorkType.Size = new System.Drawing.Size(496, 37);
            this.cmbWorkType.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(40, 135);
            this.label2.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(154, 29);
            this.label2.TabIndex = 4;
            this.label2.Text = "Вид работы:";
            // 
            // cmbDocumentType
            // 
            this.cmbDocumentType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbDocumentType.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.cmbDocumentType.FormattingEnabled = true;
            this.cmbDocumentType.Location = new System.Drawing.Point(399, 52);
            this.cmbDocumentType.Margin = new System.Windows.Forms.Padding(6);
            this.cmbDocumentType.Name = "cmbDocumentType";
            this.cmbDocumentType.Size = new System.Drawing.Size(496, 37);
            this.cmbDocumentType.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(40, 58);
            this.label1.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(319, 29);
            this.label1.TabIndex = 2;
            this.label1.Text = "Вид отчетного документа:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.cmbDocumentType);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.cmbWorkType);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.cmbWorkNumber);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.txtWorkName);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.txtWorkTopic);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.txtDiscipline);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox1.Location = new System.Drawing.Point(60, 38);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(6);
            this.groupBox1.Size = new System.Drawing.Size(1200, 519);
            this.groupBox1.TabIndex = 18;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Настройки работы";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1827, 925);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.CreateReceipt);
            this.Controls.Add(this.CreateWord);
            this.Controls.Add(this.groupBox3);
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numAfterSpacing)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numBeforeSpacing)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button CreateWord;
        private System.Windows.Forms.Button CreateReceipt;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtCheckerName;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox cmbCheckerPosition;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox cmbLineSelector;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.NumericUpDown numBeforeSpacing;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.NumericUpDown numAfterSpacing;
        private System.Windows.Forms.Button btnApplySpacing;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtSelectedLine;
        private System.Windows.Forms.TextBox txtDiscipline;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtWorkTopic;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtWorkName;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cmbWorkNumber;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cmbWorkType;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cmbDocumentType;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}